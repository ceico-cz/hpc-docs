"""Native companion for the Firefox-to-Colab SSH bridge."""

__version__ = "0.1.0"

