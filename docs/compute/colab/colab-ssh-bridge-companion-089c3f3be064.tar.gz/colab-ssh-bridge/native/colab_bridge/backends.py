"""Slurm-over-SSH session implementation."""

from __future__ import annotations

import asyncio
import re
import shlex
import shutil
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from typing import Any, Awaitable, Callable
from urllib.parse import quote

from .downloads import KINDS, RUNTIME_ROOT_SH, VERSION_RE, download_url, latest_project_release
from .models import (
    ACCOUNT_RE,
    ID_RE,
    PARTITION_RE,
    ValidationError,
    pre_turing_gpu,
    uses_gpu,
    validate_profile,
)
from .protocol import log, redact
from .relay import MUX_WINDOW, REMOTE_MUX_PROGRAM, MuxRelay
from .ssh import (
    CommandResult,
    AUTH_FAILED_RE,
    SshAuthError,
    UnknownHostKeyError,
    remote_command,
    remote_path_expr,
    run_ssh,
    ssh_base,
    ssh_error,
    ssh_error_text,
    ssh_target,
    unknown_host_key,
)


EventSink = Callable[[dict[str, Any]], Awaitable[None]]
JOB_ID_RE = re.compile(r"^[0-9]+$")
TOKEN_RE = re.compile(r"^[A-Za-z0-9._~-]{8,512}$")
SQUEUE_FORMAT = "--format=%i|%T|%N|%C|%m|%L|%b"
DURATION_RE = re.compile(r"^(?:(\d+)-)?(?:(\d+):)?(\d+):(\d+)$")
MEMORY_VALUE_RE = re.compile(r"^[0-9]+(?:\.[0-9]+)?[KMGTP]?$", re.IGNORECASE)
GPU_COUNT_RE = re.compile(r"gpu(?::[A-Za-z0-9_.-]+)*[:=]([0-9]+)", re.IGNORECASE)
# Tolerate squeue's per-poll rounding so an unchanged job does not re-emit events.
ENDS_AT_TOLERANCE = timedelta(seconds=90)
# Backoff between retries of a failed squeue/sacct/metadata call (about two minutes).
SLURM_RETRY_DELAYS = (2.0, 5.0, 10.0, 20.0, 30.0, 45.0)
# Seconds between queue polls while the job waits or its runtime starts, then while it runs.
SLURM_QUEUE_INTERVAL = 5.0
SLURM_WATCH_INTERVAL = 10.0
# Older Slurm releases exit non-zero instead of printing nothing for a finished job.
SQUEUE_UNKNOWN_JOB_RE = re.compile(r"invalid job id", re.IGNORECASE)


class SlurmQueryError(RuntimeError):
    """An SSH or Slurm command failed, so the job state is unknown rather than ended."""


def parse_slurm_duration(value: str) -> int | None:
    """Return seconds for squeue durations such as 1-02:03:04, 7:59:12, or 45:00."""
    match = DURATION_RE.fullmatch(value.strip())
    if not match:
        return None
    days, hours, minutes, seconds = (int(part or 0) for part in match.groups())
    return ((days * 24 + hours) * 60 + minutes) * 60 + seconds


@dataclass(frozen=True)
class QueueInfo:
    state: str
    node: str
    cpus: int | None
    memory: str | None
    gpus: int | None
    time_left: int | None


def parse_squeue_jobs(stdout: str) -> dict[str, QueueInfo]:
    """Map job ids to queue entries from `squeue --format` output led by %i."""
    jobs = {}
    for line in stdout.splitlines():
        job_id, separator, rest = line.strip().partition("|")
        if separator and JOB_ID_RE.fullmatch(job_id):
            jobs[job_id] = parse_squeue_line(rest)
    return jobs


def parse_squeue_line(line: str) -> QueueInfo:
    fields = [item.strip() for item in line.split("|")]
    fields += [""] * (6 - len(fields))
    state, node, cpus, memory, time_left, tres = fields[:6]
    gpu_match = GPU_COUNT_RE.search(tres)
    return QueueInfo(
        state=state.upper(),
        node=node,
        cpus=int(cpus) if cpus.isdigit() else None,
        memory=memory.upper() if MEMORY_VALUE_RE.fullmatch(memory) else None,
        gpus=int(gpu_match.group(1)) if gpu_match else (0 if tres in {"", "N/A"} else None),
        time_left=parse_slurm_duration(time_left),
    )


@dataclass
class Session:
    session_id: str
    profile_id: str
    backend: str
    state: str = "idle"
    local_port: int | None = None
    # The port a previous browser run used, reused so open notebooks keep their URL.
    preferred_port: int | None = field(default=None, repr=False)
    job_id: str | None = None
    node: str | None = None
    remote_port: int | None = None
    tunnel: MuxRelay | None = None
    monitor: asyncio.Task[None] | None = None
    error: str | None = None
    cpus: int | None = None
    memory: str | None = None
    gpus: int | None = None
    ends_at: str | None = None
    backend_url: str | None = field(default=None, repr=False)
    stop_requested: bool = field(default=False, repr=False)
    lock: asyncio.Lock = field(default_factory=asyncio.Lock, repr=False)

    def public(self, include_url: bool = False) -> dict[str, Any]:
        value: dict[str, Any] = {
            "session_id": self.session_id,
            "profile_id": self.profile_id,
            "backend": self.backend,
            "state": self.state,
            "local_port": self.local_port,
            "job_id": self.job_id,
            "node": self.node,
            "error": self.error,
            "cpus": self.cpus,
            "memory": self.memory,
            "gpus": self.gpus,
            "ends_at": self.ends_at,
        }
        if include_url and self.backend_url:
            value["backend_url"] = self.backend_url
        return value


class SessionManager:
    def __init__(self, emit: EventSink) -> None:
        self.emit = emit
        self.sessions: dict[str, Session] = {}
        # Per profile: the latest batched squeue result, and the batch in flight.
        self._queue_results: dict[str, tuple[float, dict[str, QueueInfo | None]]] = {}
        self._queue_batches: dict[str, asyncio.Task[dict[str, QueueInfo | None]]] = {}

    async def launch(self, profile: dict[str, Any], session_id: str) -> Session:
        self._validate_session_id(session_id)
        if session_id in self.sessions:
            raise ValueError(f"session already exists: {session_id}")
        session = Session(session_id, profile["id"], profile["backend"])
        self.sessions[session_id] = session
        session.monitor = asyncio.create_task(self._launch_slurm(session, profile))
        return session

    async def attach(
        self, profile: dict[str, Any], session_id: str, local_port: int | None = None
    ) -> Session:
        self._validate_session_id(session_id)
        current = self.sessions.get(session_id)
        if current and current.state in {"ready", "queued", "allocated", "starting"}:
            return current
        session = Session(session_id, profile["id"], profile["backend"])
        session.preferred_port = local_port
        self.sessions[session_id] = session
        session.monitor = asyncio.create_task(self._attach_slurm(session, profile))
        return session

    async def disconnect(self, session_id: str) -> Session:
        session = self._get(session_id)
        if session.tunnel:
            await session.tunnel.close()
            session.tunnel = None
        if session.state == "ready":
            session.state = "idle"
        await self._event(session, session.state)
        return session

    async def cancel(self, profile: dict[str, Any], session_id: str) -> Session:
        return await self.stop(profile, session_id)

    async def stop(self, profile: dict[str, Any], session_id: str) -> Session:
        session = self._get(session_id)
        if profile["id"] != session.profile_id or profile["backend"] != session.backend:
            raise ValueError("profile does not match session")
        if session.state == "finished":
            return session
        session.stop_requested = True
        await self._event(session, "stopping")
        async with session.lock:
            if session.monitor and session.monitor is not asyncio.current_task():
                session.monitor.cancel()
            if session.backend == "slurm" and session.job_id:
                result = await run_ssh(
                    profile, remote_command(["scancel", session.job_id]), timeout=20
                )
                if result.returncode:
                    raise RuntimeError(f"scancel failed: {redact(result.stderr.strip())}")
            if session.tunnel:
                await session.tunnel.close()
                session.tunnel = None
            session.backend_url = None
            await self._event(session, "finished")
            return session

    async def close(self) -> None:
        for session in self.sessions.values():
            if session.monitor:
                session.monitor.cancel()
            if session.tunnel:
                await session.tunnel.close()

    def status(self, session_id: str) -> Session:
        return self._get(session_id)

    def _get(self, session_id: str) -> Session:
        try:
            return self.sessions[session_id]
        except KeyError as error:
            raise ValueError(f"unknown session: {session_id}") from error

    @staticmethod
    def _validate_session_id(session_id: str) -> None:
        if not re.fullmatch(r"[a-f0-9-]{16,64}", session_id):
            raise ValueError("session_id must be a UUID-like lowercase identifier")

    async def _event(self, session: Session, state: str, **extra: Any) -> None:
        if session.stop_requested and state not in {"stopping", "finished"}:
            return
        session.state = state
        message = {"version": 1, "type": "event", "event": state, **session.public()}
        message.update(extra)
        await self.emit(message)

    async def _fail(self, session: Session, error: Exception | str) -> None:
        text = str(error)
        if host := unknown_host_key(text, "the login node"):
            session.error = str(UnknownHostKeyError(host))
        elif AUTH_FAILED_RE.search(text):
            session.error = str(SshAuthError("the login node"))
        else:
            session.error = ssh_error_text(text)
        await self._event(session, "failed")

    async def _launch_slurm(self, session: Session, profile: dict[str, Any]) -> None:
        try:
            await self._event(session, "starting")
            async with session.lock:
                if session.stop_requested:
                    return
                session_dir = _session_dir(session.session_id)
                prepare = f"umask 077; mkdir -p {session_dir}; chmod 700 {session_dir}"
                result = await run_ssh(profile, prepare, timeout=20)
                if result.returncode:
                    raise RuntimeError(
                        f"unable to create remote session directory: {result.stderr.strip()}"
                    )
                if session.stop_requested:
                    return
                script = build_sbatch_script(profile, session.session_id)
                submit_command = (
                    f"sbatch --parsable --output={session_dir}/slurm.out "
                    f"--error={session_dir}/slurm.err"
                )
                result = await run_ssh(
                    profile, submit_command, input_text=script, timeout=30
                )
                if result.returncode:
                    raise RuntimeError(f"sbatch failed: {result.stderr.strip()}")
                job_id = result.stdout.strip().split(";", 1)[0]
                if not JOB_ID_RE.fullmatch(job_id):
                    raise RuntimeError(
                        f"sbatch returned an invalid job id: {result.stdout.strip()!r}"
                    )
                session.job_id = job_id
                await self._write_job_id(profile, session.session_id, job_id)
            await self._event(session, "queued")
            await self._monitor_slurm(session, profile)
        except asyncio.CancelledError:
            raise
        except Exception as error:
            await self._fail(session, error)

    async def _attach_slurm(self, session: Session, profile: dict[str, Any]) -> None:
        try:
            await self._event(session, "starting")
            async with session.lock:
                if session.stop_requested:
                    return
                job_id = await self._read_job_id(profile, session.session_id)
                if not JOB_ID_RE.fullmatch(job_id):
                    raise RuntimeError("saved Slurm session has no valid job id")
                session.job_id = job_id
            await self._monitor_slurm(session, profile)
        except asyncio.CancelledError:
            raise
        except Exception as error:
            await self._fail(session, error)

    async def _monitor_slurm(self, session: Session, profile: dict[str, Any]) -> None:
        assert session.job_id
        try:
            await self._follow_slurm(session, profile)
        finally:
            # Never leave a local listener behind when monitoring ends for any reason.
            await self._close_tunnel(session)

    async def _follow_slurm(self, session: Session, profile: dict[str, Any]) -> None:
        assert session.job_id
        last_state = ""
        while True:
            info = await self._retry_slurm(
                session, lambda: self._poll_queue(session, profile, SLURM_QUEUE_INTERVAL)
            )
            if info:
                changed = self._apply_queue_info(session, info)
                if info.state != last_state:
                    last_state = info.state
                    if info.state == "PENDING":
                        await self._event(session, "queued")
                    else:
                        session.node = info.node or session.node
                        await self._event(session, "allocated")
                elif changed:
                    await self._event(session, session.state)
                metadata = await self._retry_slurm(
                    session,
                    lambda: self._read_metadata(profile, session.session_id, missing_ok=True),
                )
                if metadata.get("state") == "ready":
                    async with session.lock:
                        if session.stop_requested:
                            return
                        await self._make_slurm_ready(session, profile, metadata)
                    await self._watch_slurm(session, profile)
                    return
                await asyncio.sleep(SLURM_QUEUE_INTERVAL)
                continue

            state = await self._retry_slurm(session, lambda: self._final_state(session, profile))
            if state == "COMPLETED":
                await self._event(session, "finished")
                return
            raise RuntimeError(f"Slurm job {session.job_id} ended in state {state or 'UNKNOWN'}")

    async def _watch_slurm(self, session: Session, profile: dict[str, Any]) -> None:
        assert session.job_id
        while True:
            await asyncio.sleep(SLURM_WATCH_INTERVAL)
            info = await self._retry_slurm(
                session, lambda: self._poll_queue(session, profile, SLURM_WATCH_INTERVAL)
            )
            if info:
                if self._apply_queue_info(session, info):
                    await self._event(session, session.state)
                continue
            state = await self._retry_slurm(session, lambda: self._final_state(session, profile))
            await self._close_tunnel(session)
            if state == "COMPLETED":
                await self._event(session, "finished")
            else:
                await self._fail(session, f"Slurm job {session.job_id} ended in state {state or 'UNKNOWN'}")
            return

    async def _close_tunnel(self, session: Session) -> None:
        tunnel, session.tunnel = session.tunnel, None
        session.backend_url = None
        if tunnel:
            await tunnel.close()

    async def _retry_slurm(
        self, session: Session, call: Callable[[], Awaitable[Any]]
    ) -> Any:
        """Retry a transiently failing SSH/Slurm query with backoff before giving up."""
        for delay in (*SLURM_RETRY_DELAYS, None):
            try:
                return await call()
            except (SlurmQueryError, TimeoutError, OSError) as error:
                if delay is None or session.stop_requested:
                    raise
                log(
                    f"session {session.session_id}: Slurm query failed, "
                    f"retrying in {delay:g}s: {error}"
                )
                await asyncio.sleep(delay)
        raise AssertionError("unreachable")

    async def _poll_queue(
        self, session: Session, profile: dict[str, Any], interval: float
    ) -> QueueInfo | None:
        """Return the job's queue entry, None if Slurm no longer lists it, or raise.

        Sessions of one profile share squeue calls: a result younger than half the
        caller's poll interval is reused, and a batch already running is awaited, so
        N sessions cost about one squeue RPC per interval rather than N.
        """
        assert session.job_id
        key = session.profile_id
        loop = asyncio.get_running_loop()
        while True:
            cached = self._queue_results.get(key)
            if cached and session.job_id in cached[1] and loop.time() - cached[0] < interval / 2:
                return cached[1][session.job_id]
            batch = self._queue_batches.get(key)
            if batch is None:
                jobs = self._tracked_jobs(key, session.job_id)
                batch = asyncio.create_task(self._query_queue(key, profile, jobs))
                self._queue_batches[key] = batch
                batch.add_done_callback(lambda task: self._end_batch(key, task))
            # One session being stopped must not cancel the query the others wait on.
            results = await asyncio.shield(batch)
            if session.job_id in results:
                return results[session.job_id]
            # The batch started before this session had its job id; query again.

    def _end_batch(self, key: str, task: asyncio.Task[Any]) -> None:
        if self._queue_batches.get(key) is task:
            del self._queue_batches[key]
        if not task.cancelled():
            task.exception()  # Retrieved here too, in case every waiter was cancelled.

    def _tracked_jobs(self, profile_id: str, job_id: str) -> list[str]:
        """Return job_id and those of the profile's other sessions still being monitored."""
        jobs = {job_id}
        for session in self.sessions.values():
            if (
                session.profile_id == profile_id
                and session.job_id
                and session.monitor
                and not session.monitor.done()
            ):
                jobs.add(session.job_id)
        return sorted(jobs)

    async def _query_queue(
        self, key: str, profile: dict[str, Any], job_ids: list[str]
    ) -> dict[str, QueueInfo | None]:
        """Query the queue for these jobs in one squeue call and cache the answer."""
        started = asyncio.get_running_loop().time()
        # One id makes squeue fetch just that job. Several ids alone would make it fetch
        # every job on the cluster; --me narrows that RPC to the user's own jobs.
        scope = ["--jobs", ",".join(job_ids)]
        if len(job_ids) > 1:
            scope.insert(0, "--me")
        result = await run_ssh(
            profile,
            remote_command(["squeue", "--noheader", *scope, SQUEUE_FORMAT]),
            timeout=20,
        )
        if result.returncode:
            if (
                len(job_ids) == 1
                and result.returncode == 1
                and SQUEUE_UNKNOWN_JOB_RE.search(result.stderr)
            ):
                listed: dict[str, QueueInfo] = {}
            else:
                raise SlurmQueryError(_query_failure("squeue", result))
        else:
            listed = parse_squeue_jobs(result.stdout)
        results: dict[str, QueueInfo | None] = {job_id: listed.get(job_id) for job_id in job_ids}
        self._queue_results[key] = (started, results)
        return results

    async def _final_state(self, session: Session, profile: dict[str, Any]) -> str:
        """Return the accounting state of a job that left the queue, or "" if unrecorded."""
        assert session.job_id
        result = await run_ssh(
            profile,
            remote_command(
                [
                    "sacct",
                    "--noheader",
                    "--parsable2",
                    "--jobs",
                    session.job_id,
                    "--format=State,ExitCode",
                    "-X",
                ]
            ),
            timeout=20,
        )
        if result.returncode:
            raise SlurmQueryError(_query_failure("sacct", result))
        line = next((item.strip() for item in result.stdout.splitlines() if item.strip()), "")
        return line.split("|", 1)[0].split("+", 1)[0].upper()

    @staticmethod
    def _apply_queue_info(
        session: Session, info: QueueInfo, now: datetime | None = None
    ) -> bool:
        """Copy allocation details onto the session and report whether they changed."""
        ends_at = session.ends_at
        if info.state == "RUNNING" and info.time_left is not None:
            current = now or datetime.now(timezone.utc)
            estimate = current + timedelta(seconds=info.time_left)
            previous = datetime.fromisoformat(ends_at) if ends_at else None
            if previous is None or abs(estimate - previous) > ENDS_AT_TOLERANCE:
                ends_at = estimate.replace(microsecond=0).isoformat()
        elif info.state != "RUNNING":
            ends_at = None
        values = {
            "cpus": info.cpus if info.cpus is not None else session.cpus,
            "memory": info.memory or session.memory,
            "gpus": info.gpus if info.gpus is not None else session.gpus,
            "ends_at": ends_at,
        }
        changed = any(getattr(session, key) != value for key, value in values.items())
        for key, value in values.items():
            setattr(session, key, value)
        return changed

    async def _make_slurm_ready(
        self, session: Session, profile: dict[str, Any], metadata: dict[str, str]
    ) -> None:
        port_text = metadata.get("public_port", "")
        token = metadata.get("token", "")
        if not port_text.isdigit() or not 1 <= int(port_text) <= 65535:
            raise RuntimeError("worker metadata has an invalid public port")
        if not TOKEN_RE.fullmatch(token):
            raise RuntimeError("worker metadata has an invalid token")
        session.remote_port = int(port_text)
        session.node = metadata.get("node") or session.node
        session.job_id = metadata.get("job_id") or session.job_id

        # One overlapping step carries every browser connection; the relay starts it on
        # the first connection and again if SSH or the step drops.
        async def connection_factory() -> asyncio.subprocess.Process:
            assert session.job_id and session.remote_port
            remote = remote_command(srun_relay_args(session.job_id, session.remote_port))
            return await asyncio.create_subprocess_exec(
                *ssh_base(profile),
                ssh_target(profile),
                remote,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )

        relay = MuxRelay(connection_factory, local_port=session.preferred_port or 0)
        try:
            session.local_port = await relay.start()
        except OSError as error:
            if not session.preferred_port:
                raise
            log(
                f"session {session.session_id}: port {session.preferred_port} is "
                f"unavailable, using a new one: {error}"
            )
            relay = MuxRelay(connection_factory)
            session.local_port = await relay.start()
        session.tunnel = relay
        session.backend_url = _local_backend_url(session.local_port, token)
        await self._event(session, "ready", backend_url=session.backend_url)

    async def _read_metadata(
        self, profile: dict[str, Any], session_id: str, *, missing_ok: bool = False
    ) -> dict[str, str]:
        path = f"{_session_dir(session_id)}/runtime.env"
        result = await run_ssh(profile, f"test -r {path} && cat {path}", timeout=15)
        if result.returncode:
            if missing_ok:
                return {}
            raise RuntimeError("remote session metadata is unavailable")
        values: dict[str, str] = {}
        for line in result.stdout.splitlines():
            key, separator, value = line.partition("=")
            if separator and re.fullmatch(r"[a-z_]+", key):
                values[key] = value.strip()
        return values

    async def _write_job_id(
        self, profile: dict[str, Any], session_id: str, job_id: str
    ) -> None:
        path = f"{_session_dir(session_id)}/job.id"
        command = f"umask 077; printf '%s\\n' {shlex.quote(job_id)} > {path}"
        result = await run_ssh(profile, command, timeout=15)
        if result.returncode:
            raise RuntimeError(f"unable to save remote Slurm job id: {result.stderr.strip()}")

    async def _read_job_id(self, profile: dict[str, Any], session_id: str) -> str:
        path = f"{_session_dir(session_id)}/job.id"
        result = await run_ssh(profile, f"test -r {path} && cat {path}", timeout=15)
        if result.returncode:
            metadata = await self._read_metadata(profile, session_id, missing_ok=True)
            return metadata.get("job_id", "")
        return result.stdout.strip()


def _query_failure(name: str, result: CommandResult) -> str:
    detail = redact(result.stderr.strip()) or "no error output"
    return f"{name} exited with status {result.returncode}: {detail}"


def srun_relay_args(job_id: str, remote_port: int) -> list[str]:
    return [
        "srun",
        f"--jobid={job_id}",
        "--overlap",
        # srun line-buffers task stdout by default, stalling binary relay data.
        "--unbuffered",
        "--nodes=1",
        "--ntasks=1",
        "python3",
        "-c",
        REMOTE_MUX_PROGRAM,
        str(remote_port),
        str(MUX_WINDOW),
    ]


def _local_backend_url(port: int, token: str) -> str:
    return f"http://127.0.0.1:{port}/?token={quote(token, safe='')}"


# Per-session job logs and runtime metadata on the cluster: XDG_STATE_HOME's default under
# the shared home, fixed so the login shell and the Slurm job always agree on it.
STATE_ROOT = "~/.local/state/colab-ssh-bridge"


def _session_dir(session_id: str) -> str:
    return f"{remote_path_expr(STATE_ROOT)}/sessions/{shlex.quote(session_id)}"


# How many times a job starts the runtime on fresh ports after another process took one.
PORT_ATTEMPTS = 3
# Seconds the runtime gets to listen on its ports before the job gives up.
READY_TIMEOUT = 600

# Port helper the Slurm job runs on the compute node, which other jobs may share.
#   pick N: print N free loopback ports outside the kernel's ephemeral range.
#   check PID PUBLIC JUPYTER KMP FILESHIM: print "ready" once PID's process tree listens
#     on the public and Jupyter ports, "conflict PORT" when another process listens on one
#     of the four, and "waiting" otherwise.
PORTS_PROGRAM = r'''
import os
import random
import socket
import sys


def pick(count):
    # bind(0) and outgoing connections draw from the ephemeral range, so a port outside it
    # is only taken by a process that asks for that very number.
    try:
        with open("/proc/sys/net/ipv4/ip_local_port_range") as stream:
            low, high = (int(value) for value in stream.read().split())
    except (OSError, ValueError):
        low, high = 32768, 60999
    candidates = [port for port in range(10000, 65536) if not low <= port <= high]
    random.SystemRandom().shuffle(candidates)
    held = []
    for port in candidates:
        if len(held) == count:
            break
        sock = socket.socket()
        try:
            sock.bind(("127.0.0.1", port))
        except OSError:
            sock.close()
            continue
        held.append(sock)
    while len(held) < count:
        sock = socket.socket()
        sock.bind(("127.0.0.1", 0))
        held.append(sock)
    print(*(sock.getsockname()[1] for sock in held))


def listeners(port):
    """(uid, inode) of each socket listening on port, over IPv4 and IPv6."""
    found = []
    for table in ("/proc/net/tcp", "/proc/net/tcp6"):
        try:
            with open(table) as stream:
                lines = stream.read().splitlines()[1:]
        except OSError:
            continue
        for line in lines:
            fields = line.split()
            if fields[3] == "0A" and int(fields[1].rsplit(":", 1)[1], 16) == port:
                found.append((int(fields[7]), fields[9]))
    return found


def process_parents():
    parents = {}
    for entry in os.listdir("/proc"):
        if not entry.isdigit():
            continue
        try:
            with open(f"/proc/{entry}/stat") as stream:
                parents[int(entry)] = int(stream.read().rsplit(")", 1)[1].split()[1])
        except (OSError, IndexError, ValueError):
            continue
    return parents


def descendants(root, parents):
    children = {}
    for pid, parent in parents.items():
        children.setdefault(parent, []).append(pid)
    tree, stack = set(), [root]
    while stack:
        pid = stack.pop()
        if pid not in tree:
            tree.add(pid)
            stack.extend(children.get(pid, ()))
    return tree


def socket_holders(inodes, pids):
    """Readable processes holding each socket inode."""
    wanted = {f"socket:[{inode}]": inode for inode in inodes}
    holders = {inode: set() for inode in inodes}
    for pid in pids:
        try:
            fds = os.listdir(f"/proc/{pid}/fd")
        except OSError:
            continue
        for fd in fds:
            try:
                target = os.readlink(f"/proc/{pid}/fd/{fd}")
            except OSError:
                continue
            if target in wanted:
                holders[wanted[target]].add(pid)
    return holders


def check(root, ports):
    uid = os.getuid()
    found = {port: listeners(port) for port in ports}
    inodes = [inode for entries in found.values() for owner, inode in entries if owner == uid]
    tree = set()
    holders = {}
    if inodes:
        parents = process_parents()
        tree = descendants(root, parents)
        holders = socket_holders(inodes, parents)
    ours = set()
    for port, entries in found.items():
        for owner, inode in entries:
            pids = holders.get(inode, set())
            # A socket whose holder cannot be read is assumed to be ours: guessing wrong
            # only delays a conflict until the runtime fails on it.
            if owner != uid or (pids and not pids & tree):
                print("conflict", port)
                return
            ours.add(port)
    print("ready" if set(ports[:2]) <= ours else "waiting")


if sys.argv[1] == "pick":
    pick(int(sys.argv[2]))
else:
    check(int(sys.argv[2]), [int(port) for port in sys.argv[3:]])
'''


def build_sbatch_script(profile: dict[str, Any], session_id: str) -> str:
    session_dir = _session_dir(session_id)
    image = remote_path_expr(profile["image_path"])
    content = remote_path_expr(profile["content_dir"])
    state_root = remote_path_expr(STATE_ROOT)
    gres = (
        f"#SBATCH --gres={profile['gres_type']}:{profile['gres_count']}\n"
        if profile["gres_count"]
        else ""
    )
    account = f"#SBATCH --account={profile['account']}\n" if profile["account"] else ""
    job_name = f"colab-{session_id.replace('-', '')[:12]}"
    # run.sh only passes the GPUs into the container (apptainer --nv) for the gpu variant.
    variant = "gpu" if uses_gpu(profile) else "cpu"
    return f"""#!/usr/bin/env bash
#SBATCH --job-name={job_name}
#SBATCH --time={profile['walltime']}
#SBATCH --partition={profile['partition']}
#SBATCH --ntasks=1
#SBATCH --cpus-per-task={profile['cpus']}
#SBATCH --mem={profile['memory']}
{account}{gres}
set -euo pipefail
umask 077
session_dir={session_dir}
mkdir -p "$session_dir" {content} {state_root}/runtime/{shlex.quote(session_id)}
chmod 700 "$session_dir"
ports_helper="$session_dir/ports.py"
cat >"$ports_helper" <<'PY'
{PORTS_PROGRAM.strip()}
PY
metadata="$session_dir/runtime.env"
log_file="$session_dir/runtime.log"
public_port=""
write_metadata() {{
  {{
    printf 'state=%s\\n' "$1"
    printf 'job_id=%s\\n' "$SLURM_JOB_ID"
    printf 'node=%s\\n' "$HOSTNAME"
    printf 'public_port=%s\\n' "$public_port"
    if [[ -n "${{token:-}}" ]]; then printf 'token=%s\\n' "$token"; fi
  }} >"$metadata.tmp"
  chmod 600 "$metadata.tmp"
  mv -f "$metadata.tmp" "$metadata"
}}
write_metadata starting
{RUNTIME_ROOT_SH}# Resolve the release once, so an update during the job cannot swap scripts under it.
if ! project=$(readlink -e -- "$runtime_root/current"); then
  echo "col-app is not installed in $runtime_root; validate the profile to install it" >"$log_file"
  write_metadata failed
  exit 1
fi
runtime_token=$(od -An -N24 -tx1 /dev/urandom | tr -d ' \\n')
runtime_pid=""
stop_attempt() {{
  kill -TERM "$runtime_pid" 2>/dev/null || true
  wait "$runtime_pid" 2>/dev/null || true
}}
fail() {{
  printf '[bridge] %s\\n' "$1" >>"$log_file"
  write_metadata failed
  exit 1
}}
: >"$log_file"
# Other jobs on the node can take a port between picking and binding it; the runtime then
# starts again on fresh ports.
for attempt in $(seq 1 {PORT_ATTEMPTS}); do
  read -r public_port jupyter_port kmp_port fileshim_port < <(python3 "$ports_helper" pick 4)
  ports="$public_port $jupyter_port $kmp_port $fileshim_port"
  printf '[bridge] attempt %s on ports %s\\n' "$attempt" "$ports" >>"$log_file"
  log_offset=$(stat -c %s -- "$log_file")
  env \
    COLAB_VARIANT={variant} \
    COLAB_IMAGE={image} \
    COLAB_CONTENT_DIR={content} \
    COLAB_STATE_DIR={state_root}/runtime/{shlex.quote(session_id)} \
    COLAB_RUN_DIR={state_root}/runtime/{shlex.quote(session_id)} \
    COLAB_TOKEN="$runtime_token" \
    COLAB_PORT="$public_port" \
    COLAB_JUPYTER_PORT="$jupyter_port" \
    COLAB_KMP_PORT="$kmp_port" \
    COLAB_FILESHIM_PORT="$fileshim_port" \
    "$project/run.sh" >>"$log_file" 2>&1 &
  runtime_pid=$!
  status=waiting
  for _ in $(seq 1 {READY_TIMEOUT}); do
    if ! kill -0 "$runtime_pid" 2>/dev/null; then
      status=exited
      break
    fi
    # $ports stays unquoted: it holds the four port arguments.
    # shellcheck disable=SC2086
    status=$(python3 "$ports_helper" check "$runtime_pid" $ports) || status=error
    [[ "$status" == waiting ]] || break
    sleep 1
  done
  case $status in
    ready)
      token=$runtime_token
      write_metadata ready
      break
      ;;
    conflict*)
      printf '[bridge] another process listens on port %s; restarting\\n' "${{status#conflict }}" >>"$log_file"
      stop_attempt
      ;;
    exited)
      set +e
      wait "$runtime_pid"
      exit_code=$?
      set -e
      if tail -c +"$((log_offset + 1))" -- "$log_file" |
        grep -qiE 'address already in use|EADDRINUSE|errno 98'; then
        printf '[bridge] a port was taken; restarting\\n' >>"$log_file"
        continue
      fi
      write_metadata failed
      exit "$exit_code"
      ;;
    error)
      stop_attempt
      fail "the port check failed"
      ;;
    *)
      stop_attempt
      fail "the runtime did not listen on its ports within {READY_TIMEOUT} s"
      ;;
  esac
done
[[ -n "${{token:-}}" ]] || fail "no free ports after {PORT_ATTEMPTS} attempts"
set +e
wait "$runtime_pid"
exit_code=$?
set -e
write_metadata finished
exit "$exit_code"
"""


VALIDATION_SESSION_ID = "00000000-0000-0000-0000-000000000000"
MEMORY_UNITS_MB = {"K": 1 / 1024, "M": 1, "G": 1024, "T": 1024 * 1024}
# One sinfo %G entry: name[:type]:count, optionally followed by "(S:0-1)" socket details.
GRES_ENTRY_RE = re.compile(r"^([A-Za-z0-9_.-]+)(?::([A-Za-z0-9_.-]+))?:([0-9]+)")
GRES_SPLIT_RE = re.compile(r",(?![^()]*\))")
# Shared image paths go straight into a profile, so keep them to plain characters.
PATH_SAFE_RE = re.compile(r"/[A-Za-z0-9_.+/-]+")

# Read-only probes: report whether paths exist or could be created, never create them.
REMOTE_PATH_CHECKS = r"""
check_creatable() {
  local label=$1 path=$2 parent
  if [ -e "$path" ]; then
    if [ -d "$path" ] && [ -w "$path" ] && [ -x "$path" ]; then
      echo "$label|1|$path exists and is writable"
    else
      echo "$label|0|$path exists but is not a writable directory"
    fi
    return
  fi
  parent=$(dirname -- "$path")
  while [ ! -e "$parent" ]; do parent=$(dirname -- "$parent"); done
  if [ -d "$parent" ] && [ -w "$parent" ] && [ -x "$parent" ]; then
    echo "$label|1|$path can be created under $parent"
  else
    echo "$label|0|$path cannot be created: $parent is not a writable directory"
  fi
}
missing=""
for name in sbatch squeue sacct scancel srun sinfo apptainer python3; do
  command -v "$name" >/dev/null 2>&1 || missing="$missing $name"
done
if [ -n "$missing" ]; then
  echo "commands|0|missing on login node:$missing"
else
  echo "commands|1|Slurm, Apptainer and python3 available"
fi
if [ ! -e "$runtime_root/current" ]; then
  echo "project|m|col-app is not installed in $runtime_root"
else
  project=$(readlink -e -- "$runtime_root/current")
  if [ ! -x "$project/run.sh" ]; then
    echo "project|0|$project has no executable run.sh"
  else
    echo "project|1|col-app installed in $project"
    printf 'runtime_version|%s\n' "${project##*/}"
  fi
fi
if [ ! -e "$image" ]; then
  echo "image|m|$image not found"
elif [ ! -f "$image" ]; then
  echo "image|0|$image is not a regular file"
elif [ ! -r "$image" ]; then
  echo "image|0|$image is not readable"
else
  echo "image|1|$image is readable"
fi
check_creatable content "$content"
check_creatable state "$state"
# nvcc marks a CUDA toolkit; only GRES jobs need it, and absence is a warning, not a failure.
if [ "${want_cuda:-0}" = 1 ] && [ -f "$image" ] && [ -r "$image" ]; then
  if ! command -v apptainer >/dev/null 2>&1; then
    echo "cuda|w|apptainer missing; cannot look for nvcc in $image"
  else
    found=$(timeout 20 apptainer exec --contain --cleanenv --no-home "$image" sh -c '
      command -v nvcc && exit 0
      for candidate in /usr/local/cuda/bin/nvcc /usr/local/cuda-*/bin/nvcc /opt/conda/bin/nvcc; do
        [ -x "$candidate" ] && { echo "$candidate"; exit 0; }
      done
      exit 3' 2>/dev/null)
    status=$?
    case $status in
      0) echo "cuda|1|nvcc found at ${found%%$'\n'*}" ;;
      3) echo "cuda|w|nvcc not found in $image; the container has no CUDA support for the requested GRES" ;;
      124) echo "cuda|w|timed out looking for nvcc in $image" ;;
      *) echo "cuda|w|could not run $image to look for nvcc (exit $status)" ;;
    esac
  fi
fi
"""
# Read-only cluster discovery for the profile editor; every line is "key|value".
CLUSTER_PROBE = r"""
printf 'user|%s\n' "$(id -un)"
missing=""
for name in sbatch squeue sacct scancel srun sinfo apptainer python3; do
  command -v "$name" >/dev/null 2>&1 || missing="$missing $name"
done
printf 'missing|%s\n' "$missing"
printf 'slurm|%s\n' "$(sinfo --version 2>/dev/null | head -n 1)"
printf 'apptainer|%s\n' "$(apptainer --version 2>/dev/null | head -n 1)"
printf 'cluster|%s\n' "$(scontrol show config 2>/dev/null | sed -n 's/^ClusterName *= *//p' | head -n 1)"
sinfo --noheader --format='%P|%a|%l|%c|%m|%G' 2>/dev/null | sed 's/^/sinfo|/'
"""
# Read-only directories where some clusters publish ready-made images (Phoebe: CVMFS).
# Detected by existence, not by cluster name, so a renamed or cloned cluster still works.
SHARED_IMAGE_DIRS = ("/cvmfs/apptainer.phoebe.lan/colab",)
MAX_SHARED_IMAGES = 20


def shared_image_listing(directories: tuple[str, ...]) -> str:
    """Probe lines "image|path|bytes" for readable SIFs; a hung CVMFS mount is cut off."""
    return "".join(
        f"timeout 10 find {shlex.quote(directory)} -maxdepth 1 -name '*.sif' -type f -readable "
        "-printf 'image|%p|%s\\n' 2>/dev/null | head -n "
        f"{MAX_SHARED_IMAGES}\n"
        for directory in directories
    )


CLUSTER_PROBE += shared_image_listing(SHARED_IMAGE_DIRS)

# Per-account scratch where each user keeps their own copy of the image (IT4I clusters).
# Detected by existence, like SHARED_IMAGE_DIRS; a user in several projects gets one per account.
PROJECT_SCRATCH_ROOT = "/scratch/project"

# Read-only account discovery; $partition (optional) selects the partition to test against.
# The no-account test submission is what tells whether the cluster insists on --account:
# sites such as IT4I give every user a default account that may not submit jobs.
ACCOUNT_PROBE = f"project_root={shlex.quote(PROJECT_SCRATCH_ROOT)}\n" + r"""
account_user=$(id -un)
if command -v sacctmgr >/dev/null 2>&1; then
  assocs=$(timeout 15 sacctmgr --noheader --parsable2 show assoc where user="$account_user" \
    format=account,partition,maxsubmit,grpsubmit 2>/dev/null)
  printf '%s\n' "$assocs" | sed '/^$/d; s/^/assoc|/'
  # Users of the accounts that may submit jobs, including this one to show the listing worked;
  # zero-limit defaults such as IT4I's defac hold every user of the cluster and are skipped.
  printf 'user|%s\n' "$account_user"
  shared=$(printf '%s\n' "$assocs" | awk -F'|' '$1 != "" && $3 != "0" && $4 != "0" {print $1}' \
    | sort -u | head -n 20 | paste -sd, -)
  if [ -n "$shared" ]; then
    timeout 15 sacctmgr --noheader --parsable2 show assoc where account="$shared" format=account,user \
      2>/dev/null | awk -F'|' '$2 != ""' | sort -u | head -n 2000 \
      | sed 's/^/member|/'
  fi
  # Project scratch directories (IT4I: /scratch/project/<account>) where a SIF can be kept.
  if [ -n "$shared" ] && [ -d "$project_root" ]; then
    printf '%s\n' "$shared" | tr ',A-Z' '\na-z' | while IFS= read -r account; do
      dir="$project_root/$account"
      if timeout 5 test -d "$dir" && { timeout 5 test -w "$dir" || timeout 5 test -w "$dir/$account_user"; }; then
        printf 'project_dir|%s\n' "$account"
      fi
    done
  fi
  printf 'default_account|%s\n' "$(timeout 15 sacctmgr --noheader --parsable2 show user "$account_user" \
    format=defaultaccount 2>/dev/null | head -n 1)"
fi
printf 'enforce|%s\n' "$(scontrol show config 2>/dev/null | sed -n 's/^AccountingStorageEnforce *= *//p' | head -n 1)"
if command -v sbatch >/dev/null 2>&1; then
  output=$(timeout 20 sbatch --test-only --nodes=1 --time=00:01:00 ${partition:+--partition="$partition"} \
    --wrap=true 2>&1 </dev/null)
  status=$?
  printf 'no_account|%s|%s\n' "$status" "$(printf '%s' "$output" | tr '\n|' '  ' | cut -c 1-400)"
fi
"""
CLUSTER_PROBE += ACCOUNT_PROBE
# Login names shown as other members of an account, and how many are sent to the UI.
USER_RE = re.compile(r"^[a-zA-Z0-9_][a-zA-Z0-9_.@-]{0,63}$")
SHOWN_MEMBERS = 5
# sbatch rejections that point at the account rather than at resources or limits.
ACCOUNT_ERROR_RE = re.compile(
    r"invalid account|assoc|no (default )?account|account.{0,40}(required|specif)"
    r"|(requir|specif).{0,40}account",
    re.IGNORECASE,
)


def parse_accounts(stdout: str) -> dict[str, Any]:
    """Summarize `ACCOUNT_PROBE` output: usable accounts and whether jobs need --account."""
    partitions: dict[str, set[str]] = {}
    members: dict[str, set[str]] = {}
    project_dirs: set[str] = set()
    unrestricted: set[str] = set()
    blocked: set[str] = set()
    listed = False
    default = ""
    user = ""
    enforce = ""
    test: tuple[bool, str] | None = None
    for line in stdout.splitlines():
        key, _, rest = line.partition("|")
        if key == "assoc":
            fields = [item.strip() for item in rest.split("|")]
            if len(fields) < 4 or not ACCOUNT_RE.fullmatch(fields[0]):
                continue
            listed = True
            name, partition = fields[0].lower(), fields[1]
            # An association limited to zero submitted jobs cannot run anything.
            if "0" in (fields[2], fields[3]):
                blocked.add(name)
                continue
            if not partition:
                unrestricted.add(name)
            elif PARTITION_RE.fullmatch(partition):
                partitions.setdefault(name, set()).add(partition)
        elif key == "user":
            user = rest.strip()
        elif key == "member":
            account, _, member = (item.strip() for item in rest.partition("|"))
            if ACCOUNT_RE.fullmatch(account) and USER_RE.fullmatch(member):
                members.setdefault(account.lower(), set()).add(member)
        elif key == "project_dir" and ACCOUNT_RE.fullmatch(rest.strip()):
            project_dirs.add(rest.strip().lower())
        elif key == "default_account" and ACCOUNT_RE.fullmatch(rest.strip()):
            default = rest.strip().lower()
        elif key == "enforce":
            enforce = rest.strip().lower()
        elif key == "no_account":
            status, _, detail = rest.partition("|")
            test = (status.strip() == "0", " ".join(detail.replace("sbatch: ", "").replace("error: ", "").split()))
    usable = sorted(unrestricted | set(partitions))
    shared = {
        name: sorted(found - {user}) for name, found in members.items() if user in found
    }
    accounts = [
        {
            "name": name,
            "partitions": [] if name in unrestricted else sorted(partitions[name]),
            "default": name == default,
            # None when the site hides other users' associations (the user's own row is missing).
            "members": shared[name][:SHOWN_MEMBERS] if name in shared else None,
            "member_count": len(shared[name]) if name in shared else None,
            "image_dir": project_image_dir(name, user) if name in project_dirs else None,
        }
        for name in usable
    ]
    default_usable = default in usable
    if test and test[0]:
        required = False
        detail = (
            f"jobs without an account run under the default account {default}"
            if default else "jobs without an account are accepted"
        )
    elif test and ACCOUNT_ERROR_RE.search(test[1]):
        required = True
        detail = f"a test submission without an account was rejected: {test[1]}"
    elif listed and not default_usable and "associations" in enforce:
        required = True
        detail = (
            f"your default account {default} cannot submit jobs"
            if default else "you have no usable default account"
        )
    else:
        required = False
        detail = f"default account {default}" if default else "no account needed"
    return {
        "accounts": accounts,
        "account_required": required,
        "account_detail": detail,
        "accounts_listed": listed,
    }


def project_image_dir(account: str, user: str) -> str | None:
    """Suggested SIF directory in an account's scratch, e.g. /scratch/project/open-37-21/it4i-jose."""
    path = f"{PROJECT_SCRATCH_ROOT}/{account}/{user}"
    if not account.strip(".") or not USER_RE.fullmatch(user) or not PATH_SAFE_RE.fullmatch(path):
        return None
    return path


def evaluate_account(profile: dict[str, Any], info: dict[str, Any]) -> dict[str, Any]:
    """Check the profile's account (or its absence) against `parse_accounts` results."""
    account = profile["account"].lower()
    usable = {item["name"]: item for item in info["accounts"]}
    names = ", ".join(usable)
    if not account:
        if not info["account_required"]:
            return {"name": "Account", "ok": True, "detail": info["account_detail"]}
        if usable:
            return {
                "name": "Account",
                "ok": False,
                "detail": f"this cluster requires a Slurm account ({info['account_detail']}); choose one of: {names}",
            }
        return {
            "name": "Account",
            "ok": False,
            "detail": (
                f"this cluster requires a Slurm account ({info['account_detail']}), but none of yours "
                "can submit jobs; ask your project's PI or the cluster support to add you to a project"
            ),
        }
    if not info["accounts_listed"]:
        return {"name": "Account", "ok": True, "detail": f"{account} (accounts could not be listed)"}
    if account not in usable:
        return {
            "name": "Account",
            "ok": False,
            "detail": f"{account} is not a usable account of yours"
            + (f" (usable: {names})" if names else "; none of your accounts can submit jobs"),
        }
    allowed = usable[account]["partitions"]
    if allowed and profile["partition"] not in allowed:
        return {
            "name": "Account",
            "ok": False,
            "detail": f"{account} cannot use partition {profile['partition']} (allowed: {', '.join(allowed)})",
        }
    return {"name": "Account", "ok": True, "detail": f"{account} may submit to {profile['partition']}"}

PATH_CHECK_NAMES = {
    "commands": "Slurm commands",
    "project": "Runtime scripts",
    "image": "SIF image",
    "content": "Content directory",
    "state": "State directory",
}
# Path checks that report "m" (nothing there) and the download kind that can fill them.
MISSING_DOWNLOADS = {"image": "image", "project": "project"}
# Reported only when relevant; "w" marks a warning that does not fail validation.
OPTIONAL_PATH_CHECK_NAMES = {"cuda": "CUDA toolkit"}

# Remote checks shown beside the editor field they concern; others apply to the whole profile.
CHECK_FIELDS = {
    "SSH authentication": "ssh_target",
    "SIF image": "image_path",
    "CUDA toolkit": "image_path",
    "Content directory": "content_dir",
    "Partition": "partition",
    "Account": "account",
    "Walltime": "walltime",
    "CPUs": "cpus",
    "Memory": "memory",
    "GRES": "gres_count",
}
PROFILE_FIELDS = {
    "id",
    "name",
    "ssh_target",
    "ssh_user",
    "gres_type",
    *CHECK_FIELDS.values(),
}


def memory_megabytes(value: str) -> float | None:
    """Convert Slurm memory values such as 16G or 257000 (MB) to megabytes."""
    match = re.fullmatch(r"([0-9]+)([KMGT]?)", value.strip().rstrip("+"), re.IGNORECASE)
    if not match:
        return None
    return int(match.group(1)) * MEMORY_UNITS_MB[(match.group(2) or "M").upper()]


def parse_path_checks(stdout: str) -> list[dict[str, Any]]:
    reported: dict[str, dict[str, Any]] = {}
    optional: list[dict[str, Any]] = []
    for line in stdout.splitlines():
        key, _, rest = line.partition("|")
        ok, _, detail = rest.partition("|")
        if key in PATH_CHECK_NAMES and ok in {"0", "1", "m"}:
            reported[key] = {"name": PATH_CHECK_NAMES[key], "ok": ok == "1", "detail": detail}
            if ok == "m" and key in MISSING_DOWNLOADS:
                # Nothing exists at the path: the editor offers to fetch it from upstream.
                reported[key]["download"] = MISSING_DOWNLOADS[key]
        elif key in OPTIONAL_PATH_CHECK_NAMES and ok in {"0", "1", "w"}:
            item = {"name": OPTIONAL_PATH_CHECK_NAMES[key], "ok": ok != "0", "detail": detail}
            if ok == "w":
                item["warning"] = True
            optional.append(item)
    return [
        reported.get(key, {"name": name, "ok": False, "detail": "check did not report a result"})
        for key, name in PATH_CHECK_NAMES.items()
    ] + optional


def installed_version(stdout: str) -> str | None:
    for line in stdout.splitlines():
        key, _, value = line.partition("|")
        if key == "runtime_version" and VERSION_RE.fullmatch(value):
            return value
    return None


def runtime_check(
    item: dict[str, Any], installed: str | None, release: dict[str, Any] | str
) -> dict[str, Any]:
    """Compare the installed col-app with the upstream manifest (or why it was unreadable)."""
    item = dict(item)
    latest = release["version"] if isinstance(release, dict) else None
    if not item["ok"]:
        item["download"] = "project"
        item["detail"] += f"; latest release is {latest}" if latest else f"; upstream manifest unreadable: {release}"
    elif not latest:
        item.update(warning=True, detail=f"col-app {installed} installed; could not check for updates: {release}")
    elif installed != latest:
        item.update(
            warning=True,
            download="project",
            detail=f"col-app {installed} installed; release {latest} is available",
        )
    else:
        item["detail"] = f"col-app {installed} installed (latest release)"
    return item


def sinfo_command(partition: str) -> str:
    return remote_command(
        ["sinfo", "--noheader", f"--partition={partition}", "--format=%P|%a|%l|%c|%m|%G"]
    )


def partition_rows(partition: str, stdout: str) -> list[list[str]]:
    """Return the `sinfo_command` rows that belong to one partition."""
    rows = [
        [item.strip() for item in line.split("|")]
        for line in stdout.splitlines()
        if line.count("|") >= 5
    ]
    return [row for row in rows if row[0].rstrip("*") == partition]


def parse_gres(value: str) -> dict[str, int]:
    """Map each `name` and `name:type` in one sinfo %G field to its per-node count."""
    counts: dict[str, int] = {}
    for entry in GRES_SPLIT_RE.split(value):
        match = GRES_ENTRY_RE.match(entry.strip())
        if not match:
            continue
        name, kind, count = match.group(1), match.group(2), int(match.group(3))
        # A bare name such as "gpu" may be satisfied by any of its types on a node.
        counts[name] = counts.get(name, 0) + count
        if kind:
            counts[f"{name}:{kind}"] = counts.get(f"{name}:{kind}", 0) + count
    return counts


def partition_gres(rows: list[list[str]]) -> dict[str, int]:
    """Return the largest per-node count of each GRES across partition rows."""
    largest: dict[str, int] = {}
    for row in rows:
        for key, count in parse_gres(row[5]).items():
            largest[key] = max(largest.get(key, 0), count)
    return largest


def evaluate_partition(profile: dict[str, Any], stdout: str) -> list[dict[str, Any]]:
    """Compare profile resources with `sinfo_command` output."""
    partition = profile["partition"]
    rows = partition_rows(partition, stdout)
    if not rows:
        return [{"name": "Partition", "ok": False, "detail": f"partition {partition!r} does not exist"}]
    checks: list[dict[str, Any]] = []
    states = {row[1].lower() for row in rows}
    checks.append(
        {
            "name": "Partition",
            "ok": "up" in states,
            "detail": f"{partition} is {'/'.join(sorted(states))}",
        }
    )

    limits = [row[2] for row in rows]
    requested = parse_slurm_duration(profile["walltime"]) or 0
    if any(limit.lower() in {"infinite", "unlimited"} for limit in limits):
        checks.append({"name": "Walltime", "ok": True, "detail": "partition has no time limit"})
    else:
        parsed = [(parse_slurm_duration(limit), limit) for limit in limits]
        known = [(seconds, limit) for seconds, limit in parsed if seconds is not None]
        if known:
            longest, label = max(known)
            checks.append(
                {
                    "name": "Walltime",
                    "ok": requested <= longest,
                    "detail": f"{profile['walltime']} requested, partition maximum is {label}",
                }
            )
        else:
            checks.append(
                {"name": "Walltime", "ok": False, "detail": f"unrecognized time limit {limits[0]!r}"}
            )

    cpus = [int(row[3].rstrip("+")) for row in rows if row[3].rstrip("+").isdigit()]
    if cpus:
        checks.append(
            {
                "name": "CPUs",
                "ok": profile["cpus"] <= max(cpus),
                "detail": f"{profile['cpus']} requested, largest node has {max(cpus)}",
            }
        )

    node_memory = [value for value in (memory_megabytes(row[4]) for row in rows) if value]
    wanted_memory = memory_megabytes(profile["memory"])
    if node_memory and wanted_memory:
        checks.append(
            {
                "name": "Memory",
                "ok": wanted_memory <= max(node_memory),
                "detail": f"{profile['memory']} requested, largest node has {int(max(node_memory))}M",
            }
        )

    gres = partition_gres(rows)
    offered = ", ".join(sorted(gres)) or "none"
    wanted = profile["gres_type"]
    if profile["gres_count"]:
        largest = gres.get(wanted, 0)
        checks.append(
            {
                "name": "GRES",
                "ok": profile["gres_count"] <= largest,
                "detail": (
                    f"{profile['gres_count']} {wanted} requested, largest node has {largest}"
                    if largest
                    else f"partition {partition} offers no {wanted} (available: {offered})"
                ),
                "field": "gres_count" if largest else "gres_type",
            }
        )
        model = pre_turing_gpu(profile)
        if largest and model:
            checks.append(
                {
                    "name": "GPU model",
                    "ok": True,
                    "warning": True,
                    "detail": (
                        f"PyTorch in the Colab GPU image does not support {model} GPUs; it needs a T4 "
                        "or newer (compute capability 7.5). TensorFlow in the image can use them."
                    ),
                    "field": "gres_type",
                }
            )
    elif gres:
        checks.append(
            {"name": "GRES", "ok": True, "detail": f"none requested; partition offers {offered}"}
        )
    return checks


def summarize_partitions(stdout: str) -> list[dict[str, Any]]:
    """Summarize unfiltered `sinfo` rows per partition, for choosing one in the editor."""
    grouped: dict[str, list[list[str]]] = {}
    defaults: set[str] = set()
    for line in stdout.splitlines():
        row = [item.strip() for item in line.split("|")]
        name = row[0].rstrip("*")
        if len(row) < 6 or not PARTITION_RE.fullmatch(name):
            continue
        if row[0].endswith("*"):
            defaults.add(name)
        grouped.setdefault(name, []).append(row)
    summaries = []
    for name, rows in grouped.items():
        limits = [row[2] for row in rows]
        if any(limit.lower() in {"infinite", "unlimited"} for limit in limits):
            max_time = "infinite"
        else:
            known = [(seconds, limit) for limit in limits if (seconds := parse_slurm_duration(limit)) is not None]
            max_time = max(known)[1] if known else ""
        cpus = [int(row[3].rstrip("+")) for row in rows if row[3].rstrip("+").isdigit()]
        memory = [value for value in (memory_megabytes(row[4]) for row in rows) if value]
        summaries.append(
            {
                "name": name,
                "default": name in defaults,
                "up": any(row[1].lower() == "up" for row in rows),
                "max_time": max_time,
                "max_cpus": max(cpus, default=0),
                "max_memory_mb": int(max(memory, default=0)),
                "gres": [
                    {"type": key, "count": count}
                    for key, count in sorted(partition_gres(rows).items())
                ],
            }
        )
    return summaries


def connection_profile(raw: Any) -> dict[str, Any]:
    """Validate only a draft's connection fields; an unfinished draft must not block SSH checks."""
    if not isinstance(raw, dict):
        raise ValueError("profile must be an object")
    lookup = {key: raw[key] for key in ("ssh_target", "ssh_user") if key in raw}
    profile = validate_profile({"id": "probe", "name": "Probe", "backend": "slurm", **lookup})
    if not shutil.which("ssh"):
        raise RuntimeError("ssh executable not found")
    return profile


async def probe_cluster(raw: Any) -> dict[str, Any]:
    """Check SSH access and read cluster details for a draft's connection fields."""
    profile = connection_profile(raw)
    result = await run_ssh(profile, "bash -s", input_text=CLUSTER_PROBE, timeout=30)
    values: dict[str, str] = {}
    sinfo: list[str] = []
    images: list[dict[str, Any]] = []
    for line in result.stdout.splitlines():
        key, _, rest = line.partition("|")
        if key == "sinfo":
            sinfo.append(rest)
        elif key == "image":
            image = parse_shared_image(rest)
            if image and len(images) < MAX_SHARED_IMAGES:
                images.append(image)
        elif key in {"user", "missing", "slurm", "apptainer", "cluster"}:
            values[key] = rest.strip()
    if "user" not in values:
        raise ssh_error(result.stderr, ssh_target(profile))
    cluster = values.get("cluster", "")
    return {
        "target": ssh_target(profile),
        "user": values["user"],
        "cluster": cluster if ID_RE.fullmatch(cluster) else "",
        "slurm_version": values.get("slurm", ""),
        "apptainer_version": values.get("apptainer", ""),
        "missing_commands": values.get("missing", "").split(),
        "partitions": summarize_partitions("\n".join(sinfo)),
        "shared_images": sorted(images, key=lambda item: item["path"]),
        **parse_accounts(result.stdout),
    }


def parse_shared_image(rest: str) -> dict[str, Any] | None:
    path, _, size = rest.rpartition("|")
    if not (
        size.isdigit()
        and path.endswith(".sif")
        and path.startswith(tuple(f"{directory}/" for directory in SHARED_IMAGE_DIRS))
        and PATH_SAFE_RE.fullmatch(path)
    ):
        return None
    return {"path": path, "name": path.rsplit("/", 1)[1], "bytes": int(size)}


async def validate_remote_profile(raw: Any) -> list[dict[str, Any]]:
    """Check an unsaved Slurm profile against the cluster without submitting a job."""
    checks: list[dict[str, Any]] = []

    def add(
        name: str,
        ok: bool,
        detail: str,
        field: str | None = None,
        warning: bool = False,
        download: str | None = None,
    ) -> None:
        item = {
            "name": name,
            "ok": ok,
            "detail": redact(detail),
            "field": field or CHECK_FIELDS.get(name),
        }
        if warning:
            item["warning"] = True
        if download in KINDS:
            item["download"] = {"kind": download, "url": download_url(download, profile)}
        checks.append(item)

    if not isinstance(raw, dict) or raw.get("backend") != "slurm":
        add("Profile fields", False, "only Slurm profiles are currently supported")
        return checks
    try:
        profile = validate_profile(raw)
    except ValidationError as error:
        # Validation messages start with the offending field name.
        field = str(error).split(" ", 1)[0].split(".", 1)[0]
        add("Profile fields", False, str(error), field if field in PROFILE_FIELDS else None)
        return checks
    add("Profile fields", True, "all fields are well formed")
    if not shutil.which("ssh"):
        add("OpenSSH", False, "ssh executable not found")
        return checks

    result = await run_ssh(profile, "printf ready", timeout=15)
    if result.returncode or result.stdout != "ready":
        detail = str(ssh_error(result.stderr, ssh_target(profile))) if result.stderr.strip() else ""
        add("SSH authentication", False, detail or "unexpected response")
        return checks
    add("SSH authentication", True, f"connected to {ssh_target(profile)}")

    variables = "\n".join(
        [
            f"{name}={remote_path_expr(profile[key])}"
            for name, key in (
                ("image", "image_path"),
                ("content", "content_dir"),
            )
        ]
        + [f"state={remote_path_expr(STATE_ROOT)}"]
        + [f"want_cuda={1 if profile['gres_count'] else 0}"]
    )

    async def safe(command: str, **kwargs: Any) -> CommandResult:
        try:
            return await run_ssh(profile, command, timeout=30, **kwargs)
        except TimeoutError as error:
            return CommandResult(255, "", str(error))

    async def latest() -> dict[str, Any] | str:
        try:
            return await latest_project_release()
        except Exception as error:  # Any failure only means updates cannot be checked.
            return str(error) or type(error).__name__

    paths, sinfo, accounts, test_only, release = await asyncio.gather(
        safe("bash -s", input_text=f"{RUNTIME_ROOT_SH}{variables}\n{REMOTE_PATH_CHECKS}"),
        safe(sinfo_command(profile["partition"])),
        safe(
            "bash -s",
            input_text=f"partition={shlex.quote(profile['partition'])}\n{ACCOUNT_PROBE}",
        ),
        safe(
            "sbatch --test-only",
            input_text=build_sbatch_script(profile, VALIDATION_SESSION_ID),
        ),
        latest(),
    )
    if paths.returncode:
        add("Remote paths", False, paths.stderr.strip() or "path checks failed")
    else:
        for item in parse_path_checks(paths.stdout):
            if item["name"] == PATH_CHECK_NAMES["project"]:
                item = runtime_check(item, installed_version(paths.stdout), release)
            add(
                item["name"],
                item["ok"],
                item["detail"],
                warning=item.get("warning", False),
                download=item.get("download"),
            )
    if sinfo.returncode:
        add("Partition", False, sinfo.stderr.strip() or "sinfo failed")
    else:
        for item in evaluate_partition(profile, sinfo.stdout):
            add(item["name"], item["ok"], item["detail"], item.get("field"))
    if accounts.returncode:
        add("Account", False, accounts.stderr.strip() or "account checks failed")
    else:
        item = evaluate_account(profile, parse_accounts(accounts.stdout))
        add(item["name"], item["ok"], item["detail"])
    detail = next(
        (line.strip() for line in reversed(test_only.stderr.splitlines()) if line.strip()),
        "",
    ).removeprefix("sbatch: ")
    add(
        "Slurm test submission",
        test_only.returncode == 0,
        detail or ("job accepted (not submitted)" if test_only.returncode == 0 else "rejected"),
    )
    return checks
