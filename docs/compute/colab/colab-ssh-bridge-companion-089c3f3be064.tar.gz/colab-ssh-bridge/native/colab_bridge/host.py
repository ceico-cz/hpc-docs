"""Long-lived Firefox native-messaging host."""

from __future__ import annotations

import asyncio
import re
import traceback
from pathlib import Path
from typing import Any

from .backends import (
    SessionManager,
    connection_profile,
    probe_cluster,
    validate_remote_profile,
)
from .downloads import RemoteDownloads
from .models import ConfigStore
from .protocol import MessageWriter, ProtocolError, log, read_message
from .ssh import (
    SshAuthError,
    UnknownHostKeyError,
    local_public_keys,
    scan_host_key,
    trust_host_key,
)


class NativeHost:
    def __init__(self, store: ConfigStore | None = None, writer: MessageWriter | None = None) -> None:
        self.store = store or ConfigStore.default()
        self.writer = writer or MessageWriter()
        self.sessions = SessionManager(self._emit)
        self.downloads = RemoteDownloads(self._emit)

    async def run(self) -> None:
        try:
            while True:
                message = await asyncio.to_thread(read_message)
                if message is None:
                    break
                asyncio.create_task(self._dispatch(message))
        finally:
            await self.downloads.close()
            await self.sessions.close()

    async def _emit(self, message: dict[str, Any]) -> None:
        await asyncio.to_thread(self.writer.write, message)

    async def _dispatch(self, message: dict[str, Any]) -> None:
        request_id = message.get("request_id")
        try:
            if message.get("version") != 1:
                raise ValueError("unsupported protocol version")
            request_type = message.get("type")
            if request_type == "list_profiles":
                result: Any = self.store.profiles()
            elif request_type == "version":
                result = {"build": installed_build()}
            elif request_type == "save_profile":
                result = self.store.save_profile(message.get("profile"))
            elif request_type == "delete_profile":
                profile_id = str(message.get("profile_id", ""))
                if any(
                    session.profile_id == profile_id and session.state != "finished"
                    for session in self.sessions.sessions.values()
                ):
                    raise ValueError("profile has an active backend session")
                self.store.delete_profile(profile_id)
                result = None
            elif request_type == "launch":
                profile = self.store.get(str(message.get("profile_id", "")))
                session_id = str(message.get("session_id", ""))
                result = (await self.sessions.launch(profile, session_id)).public()
            elif request_type == "attach":
                profile = self.store.get(str(message.get("profile_id", "")))
                session_id = str(message.get("session_id", ""))
                local_port = _preferred_port(message.get("local_port"))
                result = (await self.sessions.attach(profile, session_id, local_port)).public()
            elif request_type == "status":
                result = self.sessions.status(str(message.get("session_id", ""))).public()
            elif request_type == "disconnect_tunnel":
                result = (await self.sessions.disconnect(str(message.get("session_id", "")))).public()
            elif request_type == "cancel_job":
                profile = self.store.get(str(message.get("profile_id", "")))
                result = (
                    await self.sessions.cancel(profile, str(message.get("session_id", "")))
                ).public()
            elif request_type == "stop_session":
                profile = self.store.get(str(message.get("profile_id", "")))
                result = (
                    await self.sessions.stop(profile, str(message.get("session_id", "")))
                ).public()
            elif request_type == "validate_profile":
                result = await validate_remote_profile(message.get("profile"))
            elif request_type == "probe_cluster":
                result = await probe_cluster(message.get("profile"))
            elif request_type == "scan_host_key":
                result = await scan_host_key(connection_profile(message.get("profile")))
            elif request_type == "public_keys":
                result = await local_public_keys(connection_profile(message.get("profile")))
            elif request_type == "trust_host_key":
                result = await trust_host_key(
                    connection_profile(message.get("profile")), message.get("fingerprint")
                )
            elif request_type == "download":
                result = await self.downloads.download(
                    message.get("kind"), message.get("profile"), str(message.get("download_id", ""))
                )
            elif request_type == "cancel_download":
                result = self.downloads.cancel(str(message.get("download_id", "")))
            else:
                raise ValueError(f"unknown request type: {request_type!r}")
            await self._emit(
                {
                    "version": 1,
                    "type": "response",
                    "request_id": request_id,
                    "ok": True,
                    "result": result,
                }
            )
        except Exception as error:
            log(f"request failed: {error}")
            response = {
                "version": 1,
                "type": "response",
                "request_id": request_id,
                "ok": False,
                "error": str(error),
            }
            if isinstance(error, (UnknownHostKeyError, SshAuthError)):
                response["code"] = error.code
            await self._emit(response)


def installed_build() -> str:
    """The commit install-native-host.sh recorded next to the package, if any."""
    try:
        build = (Path(__file__).resolve().parent.parent / "BUILD").read_text(encoding="utf-8").strip()
    except OSError:
        return "development"
    return build if re.fullmatch(r"[0-9a-f]{7,40}(?:-modified)?", build) else "unknown"


def _preferred_port(value: Any) -> int | None:
    """Return a saved unprivileged loopback port, or None to let the kernel pick one."""
    if isinstance(value, int) and not isinstance(value, bool) and 1024 <= value <= 65535:
        return value
    return None


def main() -> int:
    try:
        asyncio.run(NativeHost().run())
        return 0
    except (ProtocolError, BrokenPipeError) as error:
        log(str(error))
        return 1
    except KeyboardInterrupt:
        return 130
    except Exception:
        log(traceback.format_exc())
        return 1
