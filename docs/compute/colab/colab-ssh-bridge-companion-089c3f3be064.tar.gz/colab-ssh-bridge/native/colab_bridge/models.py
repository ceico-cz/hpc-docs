"""Profile validation and private native-side configuration storage."""

from __future__ import annotations

import json
import os
import re
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any


ID_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_.-]{0,63}$")
TARGET_RE = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9_.:-]{0,254}$")
WALLTIME_RE = re.compile(r"^(?:\d+-)?\d{1,2}:\d{2}:\d{2}$")
PARTITION_RE = re.compile(r"^[a-zA-Z0-9_.-]{1,32}$")
ACCOUNT_RE = re.compile(r"^[a-zA-Z0-9_.-]{1,64}$")
MEMORY_RE = re.compile(r"^[1-9][0-9]*(?:[KMGT])?$", re.IGNORECASE)
GRES_RE = re.compile(r"^[a-zA-Z0-9_.-]{1,64}(?::[a-zA-Z0-9_.-]{1,64})?$")


class ValidationError(ValueError):
    pass


def _string(value: Any, field: str, *, allow_empty: bool = False) -> str:
    if not isinstance(value, str) or (not allow_empty and not value.strip()):
        raise ValidationError(f"{field} must be a non-empty string")
    if "\x00" in value or "\n" in value or "\r" in value:
        raise ValidationError(f"{field} contains invalid control characters")
    return value.strip()


def _integer(value: Any, field: str, minimum: int, maximum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise ValidationError(f"{field} must be an integer")
    if not minimum <= value <= maximum:
        raise ValidationError(f"{field} must be between {minimum} and {maximum}")
    return value


def _remote_path(value: Any, field: str) -> str:
    path = _string(value, field)
    if not (path.startswith("/") or path.startswith("~/")):
        raise ValidationError(f"{field} must be absolute or start with ~/")
    relative = path[2:] if path.startswith("~/") else path[1:]
    if not relative or any(part in {"", ".", ".."} for part in relative.split("/")):
        raise ValidationError(f"{field} must be normalized")
    return path


# Slurm GRES names that hand the job a GPU, whole or shared.
GPU_GRES_NAMES = {"gpu", "shard", "mps"}
# GPU models older than the T4 (compute capability 7.5), the oldest that the
# PyTorch in the Colab GPU image is built for; TensorFlow there still runs on them.
PRE_TURING_GPU_RE = re.compile(r"^(?:tesla_?|nvidia_?)?(?:k\d+|m\d+|p\d+|v100\w*)$", re.IGNORECASE)


def uses_gpu(profile: dict[str, Any]) -> bool:
    gres_type = profile.get("gres_type") or ""
    return bool(profile.get("gres_count")) and gres_type.split(":", 1)[0] in GPU_GRES_NAMES


def pre_turing_gpu(profile: dict[str, Any]) -> str | None:
    """The requested GPU model when it is older than PyTorch in the image supports."""
    if not uses_gpu(profile):
        return None
    _, _, model = profile["gres_type"].partition(":")
    return model if PRE_TURING_GPU_RE.match(model) else None


def validate_profile(raw: Any) -> dict[str, Any]:
    if not isinstance(raw, dict):
        raise ValidationError("profile must be an object")
    profile_id = _string(raw.get("id"), "id")
    if not ID_RE.fullmatch(profile_id):
        raise ValidationError("id contains unsupported characters")
    backend = raw.get("backend")
    # Profiles saved before the rename used "phoebe" for the Slurm backend.
    if backend == "phoebe":
        backend = "slurm"
    if backend != "slurm":
        raise ValidationError("backend must be 'slurm'")
    # Connection options such as ProxyJump or IdentityFile belong in ~/.ssh/config,
    # under a Host alias used as ssh_target; profiles saved with ssh_options drop them.
    profile: dict[str, Any] = {
        "id": profile_id,
        "name": _string(raw.get("name"), "name"),
        "backend": backend,
        "ssh_target": _string(raw.get("ssh_target"), "ssh_target"),
    }
    if not TARGET_RE.fullmatch(profile["ssh_target"]):
        raise ValidationError("ssh_target must be a hostname or SSH config alias")
    user = raw.get("ssh_user", "")
    profile["ssh_user"] = _string(user, "ssh_user", allow_empty=True)
    if profile["ssh_user"] and not ID_RE.fullmatch(profile["ssh_user"]):
        raise ValidationError("ssh_user contains unsupported characters")

    if "gres_count" not in raw and "gpus" in raw:
        # Profiles saved before GRES selection could only request A100 GPUs.
        gres_count = _integer(raw["gpus"], "gpus", 0, 8)
        gres_type = "gpu:a100" if gres_count else ""
    else:
        gres_count = _integer(raw.get("gres_count", 0), "gres_count", 0, 1024)
        gres_type = ""
    profile.update(
        {
            "image_path": _remote_path(
                raw.get("image_path", "~/projects/colab_apptainerization/colab-cpu.sif"),
                "image_path",
            ),
            "content_dir": _remote_path(
                raw.get("content_dir", "~/colab-content"), "content_dir"
            ),
            "partition": _string(raw.get("partition", "cpu"), "partition"),
            # Empty submits under the user's default Slurm account.
            "account": _string(raw.get("account", ""), "account", allow_empty=True),
            "cpus": _integer(raw.get("cpus", 8), "cpus", 1, 256),
            "memory": _string(raw.get("memory", "16G"), "memory"),
            "walltime": _string(raw.get("walltime", "08:00:00"), "walltime"),
            "gres_type": _string(
                raw.get("gres_type", gres_type), "gres_type", allow_empty=True
            ),
            "gres_count": gres_count,
        }
    )
    if not PARTITION_RE.fullmatch(profile["partition"]):
        raise ValidationError("partition contains unsupported characters")
    if profile["account"] and not ACCOUNT_RE.fullmatch(profile["account"]):
        raise ValidationError("account contains unsupported characters")
    if not MEMORY_RE.fullmatch(profile["memory"]):
        raise ValidationError("memory must look like 16000M or 16G")
    if not WALLTIME_RE.fullmatch(profile["walltime"]):
        raise ValidationError("walltime must use HH:MM:SS or D-HH:MM:SS")
    if profile["gres_type"] and not GRES_RE.fullmatch(profile["gres_type"]):
        raise ValidationError("gres_type must look like gpu or gpu:a100")
    if profile["gres_count"] and not profile["gres_type"]:
        raise ValidationError("gres_type is required when gres_count is above 0")
    return profile


@dataclass
class ConfigStore:
    path: Path

    @classmethod
    def default(cls) -> "ConfigStore":
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
        return cls(base / "colab-ssh-bridge" / "config.json")

    def load(self) -> dict[str, Any]:
        if not self.path.exists():
            return {"version": 1, "profiles": []}
        data = json.loads(self.path.read_text(encoding="utf-8"))
        if not isinstance(data, dict) or data.get("version") != 1:
            raise ValidationError("unsupported native configuration version")
        profiles = data.get("profiles", [])
        if not isinstance(profiles, list):
            raise ValidationError("profiles must be a list")
        # The direct backend was removed; its profiles, and the runtime tokens they
        # stored, are dropped here and disappear from the file on the next write.
        validated = [
            validate_profile(item)
            for item in profiles
            if not (isinstance(item, dict) and item.get("backend") == "direct")
        ]
        return {"version": 1, "profiles": validated}

    def save_profile(self, raw: Any) -> dict[str, Any]:
        profile = validate_profile(raw)
        config = self.load()
        config["profiles"] = [p for p in config["profiles"] if p["id"] != profile["id"]]
        config["profiles"].append(profile)
        self._write(config)
        return profile

    def delete_profile(self, profile_id: str) -> None:
        config = self.load()
        remaining = [p for p in config["profiles"] if p["id"] != profile_id]
        if len(remaining) == len(config["profiles"]):
            raise ValidationError(f"unknown profile: {profile_id}")
        config["profiles"] = remaining
        self._write(config)

    def get(self, profile_id: str) -> dict[str, Any]:
        config = self.load()
        for profile in config["profiles"]:
            if profile["id"] == profile_id:
                return profile
        raise ValidationError(f"unknown profile: {profile_id}")

    def profiles(self) -> list[dict[str, Any]]:
        return self.load()["profiles"]

    def _write(self, value: dict[str, Any]) -> None:
        self.path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
        fd, temporary = tempfile.mkstemp(prefix="config.", dir=self.path.parent)
        try:
            os.fchmod(fd, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as stream:
                json.dump(value, stream, indent=2)
                stream.write("\n")
                stream.flush()
                os.fsync(stream.fileno())
            os.replace(temporary, self.path)
            os.chmod(self.path, 0o600)
        finally:
            if os.path.exists(temporary):
                os.unlink(temporary)
