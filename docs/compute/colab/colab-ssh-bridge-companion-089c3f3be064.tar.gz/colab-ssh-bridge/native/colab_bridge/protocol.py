"""Firefox native-messaging framing and safe diagnostic logging."""

from __future__ import annotations

import json
import re
import struct
import sys
import threading
from typing import Any, BinaryIO


MAX_MESSAGE_BYTES = 1024 * 1024
_TOKEN_RE = re.compile(r"(?i)(token(?:=|%3D))[^&\s\"']+")


class ProtocolError(ValueError):
    pass


def redact(value: str) -> str:
    return _TOKEN_RE.sub(r"\1<redacted>", value)


def log(message: str) -> None:
    print(redact(message), file=sys.stderr, flush=True)


def read_message(stream: BinaryIO = sys.stdin.buffer) -> dict[str, Any] | None:
    header = stream.read(4)
    if not header:
        return None
    if len(header) != 4:
        raise ProtocolError("truncated native-message header")
    (length,) = struct.unpack("=I", header)
    if length > MAX_MESSAGE_BYTES:
        raise ProtocolError(f"native message exceeds {MAX_MESSAGE_BYTES} bytes")
    payload = stream.read(length)
    if len(payload) != length:
        raise ProtocolError("truncated native-message payload")
    value = json.loads(payload.decode("utf-8"))
    if not isinstance(value, dict):
        raise ProtocolError("native message must be a JSON object")
    return value


class MessageWriter:
    def __init__(self, stream: BinaryIO = sys.stdout.buffer) -> None:
        self._stream = stream
        self._lock = threading.Lock()

    def write(self, message: dict[str, Any]) -> None:
        payload = json.dumps(message, separators=(",", ":")).encode("utf-8")
        if len(payload) > MAX_MESSAGE_BYTES:
            raise ProtocolError("outgoing native message is too large")
        with self._lock:
            self._stream.write(struct.pack("=I", len(payload)))
            self._stream.write(payload)
            self._stream.flush()

