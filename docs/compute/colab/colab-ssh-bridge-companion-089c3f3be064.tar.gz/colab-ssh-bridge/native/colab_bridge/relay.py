"""Loopback listeners that carry Colab traffic through OpenSSH."""

from __future__ import annotations

import asyncio
import contextlib
import struct
from collections.abc import Awaitable, Callable

from .protocol import log


ConnectionFactory = Callable[[], Awaitable[asyncio.subprocess.Process]]

# Relay framing, shared with REMOTE_MUX_PROGRAM: a header of stream id, frame kind and
# payload length, then the payload. The local side opens streams; ids are never reused.
MUX_HEADER = struct.Struct(">IBI")
MUX_COUNT = struct.Struct(">I")
MUX_OPEN, MUX_DATA, MUX_EOF, MUX_CLOSE, MUX_ACK = range(5)
MUX_CHUNK = 65536
# Bytes a connection may have unacknowledged in each direction, so one slow reader
# neither stalls the other connections nor buffers without bound.
MUX_WINDOW = 1 << 20
MUX_MAX_FRAME = 1 << 20

# Runs on the compute node inside one `srun --overlap` step and carries every browser
# connection of a session to the runtime's loopback port. It sticks to Python 3.6 so it
# runs on the cluster's system python3.
#   OPEN: connect a new stream; DATA: payload; EOF: half-close; CLOSE: abort the stream;
#   ACK: the receiver wrote that many bytes out and grants the sender more window.
REMOTE_MUX_PROGRAM = r'''import collections,os,socket,struct,sys,threading
PORT=int(sys.argv[1]);WINDOW=int(sys.argv[2])
HEAD=struct.Struct(">IBI");COUNT=struct.Struct(">I")
OPEN,DATA,EOF,CLOSE,ACK=range(5)
CHUNK=65536;MAX_FRAME=1<<20
inp=sys.stdin.buffer;out=sys.stdout.buffer
out_lock=threading.Lock();streams={}
def send(sid,kind,payload=b""):
  with out_lock:
    out.write(HEAD.pack(sid,kind,len(payload))+payload);out.flush()
class Stream(object):
  def __init__(self,sid):
    self.sid=sid;self.sock=None;self.queue=collections.deque();self.credit=WINDOW
    self.cv=threading.Condition();self.dead=False;self.ended=0
  def finish(self):
    with self.cv:
      self.ended+=1;last=self.ended==2 and not self.dead
      if last:self.dead=True
    if last:
      streams.pop(self.sid,None);self.sock.close()
  def abort(self,tell=True):
    with self.cv:
      if self.dead:return
      self.dead=True;self.cv.notify_all()
    streams.pop(self.sid,None)
    if self.sock is not None:
      try:self.sock.shutdown(socket.SHUT_RDWR)
      except OSError:pass
      self.sock.close()
    if tell:
      try:send(self.sid,CLOSE)
      except OSError:pass
  def inbound(self):
    try:sock=socket.create_connection(("127.0.0.1",PORT))
    except OSError:
      self.abort();return
    with self.cv:
      if self.dead:
        sock.close();return
      self.sock=sock
    threading.Thread(target=self.outbound,daemon=True).start()
    try:
      while True:
        with self.cv:
          while not self.queue and not self.dead:self.cv.wait()
          if self.dead:return
          item=self.queue.popleft()
        if item is None:
          sock.shutdown(socket.SHUT_WR);break
        sock.sendall(item);send(self.sid,ACK,COUNT.pack(len(item)))
    except OSError:
      self.abort();return
    self.finish()
  def outbound(self):
    try:
      while True:
        with self.cv:
          while self.credit<=0 and not self.dead:self.cv.wait()
          if self.dead:return
          size=min(self.credit,CHUNK)
        data=self.sock.recv(size)
        if not data:break
        with self.cv:self.credit-=len(data)
        send(self.sid,DATA,data)
      if self.dead:return
      send(self.sid,EOF)
    except OSError:
      self.abort();return
    self.finish()
while True:
  head=inp.read(HEAD.size)
  if len(head)<HEAD.size:break
  sid,kind,size=HEAD.unpack(head)
  if size>MAX_FRAME:break
  payload=inp.read(size) if size else b""
  if len(payload)<size:break
  if kind==OPEN:
    if sid in streams:break
    stream=streams[sid]=Stream(sid)
    threading.Thread(target=stream.inbound,daemon=True).start();continue
  stream=streams.get(sid)
  if stream is None:continue
  if kind==CLOSE:
    stream.abort(False);continue
  with stream.cv:
    if kind==DATA:stream.queue.append(payload)
    elif kind==EOF:stream.queue.append(None)
    elif kind==ACK and size==COUNT.size:stream.credit+=COUNT.unpack(payload)[0]
    stream.cv.notify_all()
os._exit(0)
'''


class MuxRelay:
    """Expose a local TCP port and carry all its connections over one relay process.

    The process starts with the first connection and again after it exits, so a
    session holds one SSH channel and one Slurm step however many connections the
    browser opens.
    """

    def __init__(
        self, factory: ConnectionFactory, local_port: int = 0, window: int = MUX_WINDOW
    ) -> None:
        self._factory = factory
        self.local_port = local_port
        self._window = window
        self._server: asyncio.AbstractServer | None = None
        self._tasks: set[asyncio.Task[None]] = set()
        self._link: _MuxLink | None = None
        self._link_lock = asyncio.Lock()

    async def start(self) -> int:
        self._server = await asyncio.start_server(
            self._accept, "127.0.0.1", self.local_port, start_serving=True
        )
        sockets = self._server.sockets or []
        if not sockets:
            raise RuntimeError("loopback relay did not create a socket")
        self.local_port = int(sockets[0].getsockname()[1])
        return self.local_port

    async def close(self) -> None:
        if self._server:
            self._server.close()
            await self._server.wait_closed()
            self._server = None
        for task in list(self._tasks):
            task.cancel()
        if self._tasks:
            await asyncio.gather(*self._tasks, return_exceptions=True)
        self._tasks.clear()
        async with self._link_lock:
            link, self._link = self._link, None
        if link:
            await link.close()

    async def _accept(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        task = asyncio.create_task(self._serve(reader, writer))
        self._tasks.add(task)
        task.add_done_callback(self._tasks.discard)

    async def _serve(
        self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter
    ) -> None:
        try:
            link = await self._current_link()
            await link.carry(reader, writer)
        except asyncio.CancelledError:
            raise
        except ConnectionError:
            # Browsers drop connections routinely; the runtime refusing one lands here too.
            pass
        except Exception as error:
            log(f"relay connection failed: {error}")
        finally:
            writer.close()
            with contextlib.suppress(Exception):
                await writer.wait_closed()

    async def _current_link(self) -> _MuxLink:
        async with self._link_lock:
            if self._link and self._link.closed:
                await self._link.close()
                self._link = None
            if self._link is None:
                self._link = _MuxLink(await self._factory(), self._window)
            return self._link


class _MuxStream:
    """One browser connection's state inside a relay link."""

    def __init__(self, window: int) -> None:
        self.credit = window
        self.unacked = 0
        self.inbound: asyncio.Queue[bytes | None] = asyncio.Queue()
        self.granted = asyncio.Event()
        self.aborted = False

    def grant(self, count: int) -> None:
        self.credit += count
        self.granted.set()

    def abort(self) -> None:
        if not self.aborted:
            self.aborted = True
            self.granted.set()
            self.inbound.put_nowait(None)

    async def take_credit(self, wanted: int) -> int:
        while self.credit <= 0 and not self.aborted:
            self.granted.clear()
            await self.granted.wait()
        if self.aborted:
            raise ConnectionResetError("the relay closed the connection")
        count = min(self.credit, wanted)
        self.credit -= count
        return count


class _MuxLink:
    """One relay process and the connections multiplexed over it."""

    def __init__(self, process: asyncio.subprocess.Process, window: int) -> None:
        if not process.stdin or not process.stdout:
            raise RuntimeError("relay process lacks stdio pipes")
        self.process = process
        self.window = window
        self.closed = False
        self._streams: dict[int, _MuxStream] = {}
        self._next_id = 1
        self._drain_lock = asyncio.Lock()
        self._reader = asyncio.create_task(self._read_frames())
        self._stderr = asyncio.create_task(_drain_stderr(process))

    async def close(self) -> None:
        self._shut()
        if self.process.returncode is None:
            self.process.terminate()
            with contextlib.suppress(TimeoutError):
                await asyncio.wait_for(self.process.wait(), 2)
            if self.process.returncode is None:
                self.process.kill()
                await self.process.wait()
        for task in (self._reader, self._stderr):
            task.cancel()
        await asyncio.gather(self._reader, self._stderr, return_exceptions=True)

    def _shut(self) -> None:
        self.closed = True
        for stream in self._streams.values():
            stream.abort()

    def _send(self, stream_id: int, kind: int, payload: bytes = b"") -> None:
        if self.closed:
            raise ConnectionResetError("the relay process exited")
        assert self.process.stdin
        self.process.stdin.write(MUX_HEADER.pack(stream_id, kind, len(payload)) + payload)

    async def _drain(self) -> None:
        assert self.process.stdin
        async with self._drain_lock:
            await self.process.stdin.drain()

    async def carry(self, reader: asyncio.StreamReader, writer: asyncio.StreamWriter) -> None:
        """Relay one browser connection until both directions end."""
        stream_id = self._next_id
        self._next_id += 1
        stream = _MuxStream(self.window)
        self._streams[stream_id] = stream
        self._send(stream_id, MUX_OPEN)
        tasks = [
            asyncio.create_task(self._upstream(stream_id, stream, reader)),
            asyncio.create_task(self._downstream(stream_id, stream, writer)),
        ]
        try:
            done, _ = await asyncio.wait(tasks, return_when=asyncio.FIRST_EXCEPTION)
            for task in done:
                task.result()
        except BaseException:
            if not stream.aborted and not self.closed:
                self._send(stream_id, MUX_CLOSE)
            raise
        finally:
            self._streams.pop(stream_id, None)
            for task in tasks:
                task.cancel()
            await asyncio.gather(*tasks, return_exceptions=True)

    async def _upstream(
        self, stream_id: int, stream: _MuxStream, reader: asyncio.StreamReader
    ) -> None:
        while data := await reader.read(MUX_CHUNK):
            while data:
                count = await stream.take_credit(len(data))
                self._send(stream_id, MUX_DATA, data[:count])
                data = data[count:]
                await self._drain()
        self._send(stream_id, MUX_EOF)
        await self._drain()

    async def _downstream(
        self, stream_id: int, stream: _MuxStream, writer: asyncio.StreamWriter
    ) -> None:
        while True:
            data = await stream.inbound.get()
            if stream.aborted:
                raise ConnectionResetError("the runtime closed the connection")
            if data is None:
                # The browser may already have closed its end.
                with contextlib.suppress(OSError):
                    if writer.can_write_eof():
                        writer.write_eof()
                return
            writer.write(data)
            await writer.drain()
            stream.unacked -= len(data)
            self._send(stream_id, MUX_ACK, MUX_COUNT.pack(len(data)))

    async def _read_frames(self) -> None:
        assert self.process.stdout
        try:
            while True:
                header = await self.process.stdout.readexactly(MUX_HEADER.size)
                stream_id, kind, size = MUX_HEADER.unpack(header)
                if size > MUX_MAX_FRAME:
                    raise RuntimeError(f"relay frame of {size} bytes exceeds the limit")
                payload = await self.process.stdout.readexactly(size) if size else b""
                stream = self._streams.get(stream_id)
                if stream is None or stream.aborted:
                    continue
                if kind == MUX_DATA:
                    stream.unacked += size
                    if stream.unacked > self.window:
                        stream.abort()
                        self._send(stream_id, MUX_CLOSE)
                        continue
                    stream.inbound.put_nowait(payload)
                elif kind == MUX_EOF:
                    stream.inbound.put_nowait(None)
                elif kind == MUX_ACK and size == MUX_COUNT.size:
                    stream.grant(MUX_COUNT.unpack(payload)[0])
                elif kind == MUX_CLOSE:
                    stream.abort()
        except asyncio.IncompleteReadError:
            pass
        except Exception as error:
            log(f"relay link failed: {error}")
        finally:
            self._shut()


async def _drain_stderr(process: asyncio.subprocess.Process) -> None:
    if not process.stderr:
        return
    while line := await process.stderr.readline():
        log(f"relay: {line.decode('utf-8', 'replace').rstrip()}")
