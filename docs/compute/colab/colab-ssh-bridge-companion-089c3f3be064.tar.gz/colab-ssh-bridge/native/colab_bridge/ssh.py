"""OpenSSH command construction and subprocess helpers."""

from __future__ import annotations

import asyncio
import hashlib
import os
import re
import shlex
import shutil
import stat
import tempfile
from dataclasses import dataclass
from collections.abc import Awaitable, Callable
from pathlib import Path
from typing import Any

from .models import ValidationError
from .protocol import redact


HOST_KEY_UNKNOWN_RE = re.compile(r"No \S+ host key is known for (\S+)")
# OpenSSH warns loudly about a changed or revoked key whatever StrictHostKeyChecking is.
HOST_KEY_MISMATCH_RE = re.compile(r"(?i)has changed|REVOKED|DNS SPOOFING")
FINGERPRINT_RE = re.compile(r"^SHA256:[A-Za-z0-9+/]{43}$")
# Stop after host-key verification: nothing authenticates to a host that is not yet trusted.
NO_AUTH_OPTIONS = (
    "PubkeyAuthentication=no",
    "PasswordAuthentication=no",
    "KbdInteractiveAuthentication=no",
    "GSSAPIAuthentication=no",
    "HostbasedAuthentication=no",
    "ControlPath=none",
    "UpdateHostKeys=no",
    "CheckHostIP=no",
)


AUTH_FAILED_RE = re.compile(r"Permission denied \(|Too many authentication failures")
# Advisories OpenSSH prints before the real error, such as the post-quantum key-exchange notice.
ADVISORY_RE = re.compile(r"^\*\* |^Warning: Permanently added ")


def ssh_error_text(stderr: str) -> str:
    """Return OpenSSH's error output without advisories that say nothing about the failure."""
    lines = (line.rstrip("\r") for line in stderr.splitlines())
    return redact("\n".join(line for line in lines if line.strip() and not ADVISORY_RE.match(line)))


class SshAuthError(RuntimeError):
    """The host is trusted, but refused every key the SSH client offered."""

    code = "auth_failed"

    def __init__(self, target: str) -> None:
        super().__init__(
            f"{target} refused every SSH key offered; add your public key to the "
            "cluster account, then connect again"
        )
        self.target = target


def ssh_error(stderr: str, target: str) -> RuntimeError:
    """Turn a failed connection's stderr into an error the profile editor can act on."""
    if host := unknown_host_key(stderr, target):
        return UnknownHostKeyError(host)
    if AUTH_FAILED_RE.search(stderr):
        return SshAuthError(target)
    return RuntimeError(ssh_error_text(stderr) or "SSH connection failed")


class UnknownHostKeyError(RuntimeError):
    """OpenSSH refused a host whose key is not in known_hosts yet."""

    code = "host_key_unknown"

    def __init__(self, host: str) -> None:
        super().__init__(
            f"the SSH host key for {host} is not trusted yet; "
            "connect from the profile editor to review and trust it"
        )
        self.host = host


def unknown_host_key(stderr: str, host: str = "this host") -> str | None:
    """Return the host whose key OpenSSH rejected, unless the key changed rather than is new.

    Under the default StrictHostKeyChecking=ask, BatchMode only prints "Host key
    verification failed." and never names the host; scan_host_key tells an unknown
    key from a changed one with strict checking before anything is trusted.
    """
    if match := HOST_KEY_UNKNOWN_RE.search(stderr):
        return match.group(1)
    if "Host key verification failed" in stderr and not HOST_KEY_MISMATCH_RE.search(stderr):
        return host
    return None


def ssh_target(profile: dict[str, Any]) -> str:
    target = profile["ssh_target"]
    user = profile.get("ssh_user")
    return f"{user}@{target}" if user else target


# An idle master connection outlives its last client by this many seconds, which spans
# the gaps between Slurm polls.
CONTROL_PERSIST_SECONDS = 120
# sockaddr_un holds 108 bytes; OpenSSH first binds the path plus a 17-character suffix.
CONTROL_PATH_MAX = 107 - 17


def control_dir() -> Path | None:
    """Return the private directory for SSH control sockets, or None to not multiplex.

    Anyone who can connect to a control socket runs commands as the user on the
    cluster, so the directory must be a real mode-0700 directory owned by this user.
    """
    runtime = os.environ.get("XDG_RUNTIME_DIR", "")
    if not os.path.isabs(runtime) or re.search(r"[\s%]", runtime):
        return None
    path = Path(runtime) / "colab-ssh-bridge"
    try:
        path.mkdir(mode=0o700, exist_ok=True)
        info = path.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid():
            return None
        if stat.S_IMODE(info.st_mode) != 0o700:
            path.chmod(0o700)
    except OSError:
        return None
    return path


def control_path(profile: dict[str, Any]) -> Path | None:
    """Return the control socket shared by every command for this login target.

    The name covers the target, so profiles that authenticate differently (another
    user or SSH config alias) never borrow each other's master connection.
    """
    directory = control_dir()
    if directory is None:
        return None
    path = directory / hashlib.sha256(ssh_target(profile).encode()).hexdigest()[:32]
    return path if len(str(path)) <= CONTROL_PATH_MAX else None


def ssh_base(profile: dict[str, Any], *, timeout: int = 12, multiplex: bool = True) -> list[str]:
    """Return the ssh command prefix; `multiplex` reuses one authenticated connection.

    Pass multiplex=False for a client that must make its own connection, such as a
    host-key check or a long-lived -L forward.
    """
    args = [
        "ssh",
        "-o",
        "BatchMode=yes",
        "-o",
        f"ConnectTimeout={timeout}",
        "-o",
        "ServerAliveInterval=30",
        "-o",
        "ServerAliveCountMax=3",
    ]
    # OpenSSH keeps the first value it sees for an option, so these win over ssh_config.
    socket = control_path(profile) if multiplex else None
    if socket:
        args.extend([
            "-o",
            "ControlMaster=auto",
            "-o",
            f"ControlPath={socket}",
            "-o",
            f"ControlPersist={CONTROL_PERSIST_SECONDS}",
        ])
    else:
        args.extend(["-o", "ControlMaster=no", "-o", "ControlPath=none"])
    return args


def remote_path_expr(path: str) -> str:
    if path.startswith("~/"):
        return '"$HOME"/' + shlex.quote(path[2:])
    if path.startswith("/"):
        return shlex.quote(path)
    raise ValidationError("remote path must be absolute or start with ~/")


def remote_command(parts: list[str]) -> str:
    return shlex.join(parts)


@dataclass
class CommandResult:
    returncode: int
    stdout: str
    stderr: str


async def run_ssh(
    profile: dict[str, Any],
    command: str,
    *,
    input_text: str | None = None,
    timeout: float = 30,
) -> CommandResult:
    args = [*ssh_base(profile), ssh_target(profile), command]
    return await run_command(args, input_text=input_text, timeout=timeout, name="SSH command")


async def run_command(
    args: list[str],
    *,
    input_text: str | None = None,
    timeout: float = 30,
    name: str = "command",
) -> CommandResult:
    process = await asyncio.create_subprocess_exec(
        *args,
        stdin=asyncio.subprocess.PIPE if input_text is not None else asyncio.subprocess.DEVNULL,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout, stderr = await asyncio.wait_for(
            process.communicate(input_text.encode() if input_text is not None else None),
            timeout,
        )
    except TimeoutError:
        process.kill()
        await process.wait()
        raise TimeoutError(f"{name} timed out after {timeout:g}s")
    return CommandResult(
        process.returncode,
        stdout.decode("utf-8", "replace"),
        stderr.decode("utf-8", "replace"),
    )


async def stream_ssh(
    profile: dict[str, Any],
    command: str,
    on_line: Callable[[str], Awaitable[None]],
    *,
    input_text: str | None = None,
) -> CommandResult:
    """Run a long remote command, handing each stdout line to `on_line` as it arrives.

    Cancelling the caller kills the local ssh client; the remote side then sees its
    stdout close and is expected to clean up on the resulting SIGPIPE.
    """
    args = [*ssh_base(profile), ssh_target(profile), command]
    process = await asyncio.create_subprocess_exec(
        *args,
        stdin=asyncio.subprocess.PIPE if input_text is not None else asyncio.subprocess.DEVNULL,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    stderr_task = asyncio.create_task(process.stderr.read())
    try:
        if input_text is not None:
            process.stdin.write(input_text.encode())
            await process.stdin.drain()
            process.stdin.close()
        async for raw in process.stdout:
            await on_line(raw.decode("utf-8", "replace").rstrip("\n"))
        await process.wait()
    except BaseException:
        if process.returncode is None:
            process.kill()
            await process.wait()
        stderr_task.cancel()
        raise
    return CommandResult(process.returncode, "", (await stderr_task).decode("utf-8", "replace"))


def _no_auth_args(profile: dict[str, Any], *options: str) -> list[str]:
    # A shared master would answer without contacting the host, hiding its current key.
    args = ssh_base(profile, timeout=10, multiplex=False)
    for option in (*options, *NO_AUTH_OPTIONS):
        args.extend(["-o", option])
    return [*args, ssh_target(profile), "true"]


async def _ssh_config(profile: dict[str, Any]) -> dict[str, list[str]]:
    """Return the effective client configuration; keys such as IdentityFile repeat."""
    result = await run_command(
        [*ssh_base(profile, multiplex=False), "-G", ssh_target(profile)],
        timeout=10,
        name="ssh -G",
    )
    if result.returncode:
        raise RuntimeError(ssh_error_text(result.stderr) or "unable to read the SSH configuration")
    config: dict[str, list[str]] = {}
    for line in result.stdout.splitlines():
        key, _, value = line.partition(" ")
        config.setdefault(key.lower(), []).append(value.strip())
    return config


async def _host_key_state(profile: dict[str, Any]) -> str:
    """Return "known" or "unknown"; refuse a key that differs from a trusted one."""
    result = await run_command(
        _no_auth_args(profile, "StrictHostKeyChecking=yes"), timeout=25, name="SSH host-key check"
    )
    if HOST_KEY_UNKNOWN_RE.search(result.stderr):
        return "unknown"
    if "Host key verification failed" in result.stderr:
        raise RuntimeError(
            f"the SSH host key for {ssh_target(profile)} does not match the one in known_hosts; "
            "this may be an attack or a reinstalled server. Confirm the new key with the "
            "cluster administrators and update known_hosts manually (ssh-keygen -R)."
        )
    if result.returncode == 0 or "Permission denied" in result.stderr:
        return "known"
    raise RuntimeError(ssh_error_text(result.stderr) or "SSH connection failed")


async def _capture_host_keys(profile: dict[str, Any]) -> tuple[list[str], list[dict[str, Any]]]:
    """Record the key the host offers in a scratch known_hosts file, then fingerprint it."""
    with tempfile.TemporaryDirectory(prefix="colab-bridge-") as directory:
        path = Path(directory) / "known_hosts"
        path.touch(mode=0o600)
        result = await run_command(
            _no_auth_args(
                profile,
                "StrictHostKeyChecking=accept-new",
                f'UserKnownHostsFile="{path}"',
                "GlobalKnownHostsFile=/dev/null",
            ),
            timeout=25,
            name="SSH host-key scan",
        )
        entries = [
            line for line in path.read_text().splitlines()
            if line.strip() and not line.startswith("#")
        ]
        if not entries:
            raise RuntimeError(ssh_error_text(result.stderr) or "the host did not offer a key")
        listing = await run_command(["ssh-keygen", "-l", "-f", str(path)], name="ssh-keygen")
    keys = []
    for line in listing.stdout.splitlines():
        fields = line.split()
        if len(fields) >= 3 and FINGERPRINT_RE.fullmatch(fields[1]):
            key_type = fields[-1].strip("()") if fields[-1].startswith("(") else ""
            keys.append({"type": key_type, "bits": int(fields[0]), "fingerprint": fields[1]})
    if not keys:
        raise RuntimeError("unable to fingerprint the host key")
    return entries, keys


def _known_hosts_file(config: dict[str, list[str]]) -> Path:
    files = " ".join(config.get("userknownhostsfile", [])).split()
    if not files or files[0] in {"none", "/dev/null"}:
        raise RuntimeError("the SSH configuration has no user known_hosts file to add the key to")
    return Path(os.path.expanduser(files[0]))


async def scan_host_key(profile: dict[str, Any]) -> dict[str, Any]:
    """Describe the host key of an untrusted host so the user can compare its fingerprint."""
    config = await _ssh_config(profile)
    info: dict[str, Any] = {
        "target": ssh_target(profile),
        "host": config.get("hostname", [profile["ssh_target"]])[0],
        "port": config.get("port", ["22"])[0],
        "known_hosts_file": str(_known_hosts_file(config)),
        "status": await _host_key_state(profile),
        "keys": [],
    }
    if info["status"] == "unknown":
        _, info["keys"] = await _capture_host_keys(profile)
    return info


async def trust_host_key(profile: dict[str, Any], fingerprint: Any) -> dict[str, Any]:
    """Add the host key to known_hosts if it still has the fingerprint the user approved."""
    if not isinstance(fingerprint, str) or not FINGERPRINT_RE.fullmatch(fingerprint):
        raise ValidationError("fingerprint must be an OpenSSH SHA256 fingerprint")
    config = await _ssh_config(profile)
    known_hosts = _known_hosts_file(config)
    if await _host_key_state(profile) == "known":
        return {"target": ssh_target(profile), "status": "known"}
    entries, keys = await _capture_host_keys(profile)
    if fingerprint not in {key["fingerprint"] for key in keys}:
        raise RuntimeError(
            "the host now offers a different key than the one shown; nothing was trusted"
        )
    known_hosts.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    descriptor = os.open(known_hosts, os.O_WRONLY | os.O_APPEND | os.O_CREAT, 0o600)
    with os.fdopen(descriptor, "a", encoding="utf-8") as stream:
        if stream.tell() and not known_hosts.read_bytes().endswith(b"\n"):
            stream.write("\n")
        stream.write("".join(f"{entry}\n" for entry in entries))
    if await _host_key_state(profile) != "known":
        raise RuntimeError(f"OpenSSH still does not trust the host after updating {known_hosts}")
    return {"target": ssh_target(profile), "status": "trusted", "fingerprint": fingerprint,
            "known_hosts_file": str(known_hosts)}


async def _fingerprint_lines(text: str) -> list[dict[str, Any]]:
    """Fingerprint authorized_keys-format lines; keep the public key next to each result."""
    keys = []
    for line in text.splitlines():
        fields = line.split()
        if len(fields) < 2 or line.startswith("#"):
            continue
        listing = await run_command(
            ["ssh-keygen", "-l", "-f", "/dev/stdin"], input_text=f"{line}\n", name="ssh-keygen"
        )
        parts = listing.stdout.split()
        if listing.returncode or len(parts) < 2 or not FINGERPRINT_RE.fullmatch(parts[1]):
            continue
        keys.append({
            "type": parts[-1].strip("()") if parts[-1].startswith("(") else fields[0],
            "fingerprint": parts[1],
            "comment": " ".join(fields[2:]),
            "public_key": " ".join(fields[:3]),
        })
    return keys


async def local_public_keys(profile: dict[str, Any]) -> dict[str, Any]:
    """List the public keys SSH offers this host, and how to install one on it.

    Only public halves are read: IdentityFile paths with a .pub next to them, and
    the keys an SSH agent holds.
    """
    config = await _ssh_config(profile)
    keys: dict[str, dict[str, Any]] = {}
    for raw in config.get("identityfile", []):
        if "%" in raw:
            continue
        path = Path(os.path.expanduser(raw) + ".pub")
        try:
            text = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue
        for key in await _fingerprint_lines(text):
            keys.setdefault(
                key["fingerprint"],
                {**key, "path": str(path), "private_path": os.path.expanduser(raw),
                 "agent": False, "locked": False},
            )
    if shutil.which("ssh-add"):
        agent = await run_command(["ssh-add", "-L"], timeout=10, name="ssh-add")
        if agent.returncode == 0:
            for key in await _fingerprint_lines(agent.stdout):
                keys.setdefault(
                    key["fingerprint"],
                    {**key, "path": None, "private_path": None, "agent": True, "locked": False},
                )
                keys[key["fingerprint"]]["agent"] = True
    for key in keys.values():
        # BatchMode cannot ask for a passphrase: such a key only works from the agent.
        # ssh-keygen -y prints the public half only, so nothing secret leaves this check.
        if not key["agent"] and key["private_path"] and os.path.isfile(key["private_path"]):
            check = await run_command(
                ["ssh-keygen", "-y", "-P", "", "-f", key["private_path"]],
                timeout=10,
                name="ssh-keygen",
            )
            key["locked"] = check.returncode != 0
    locked = [key["private_path"] for key in keys.values() if key["locked"]]
    target = ssh_target(profile)
    with_file = next((key for key in keys.values() if key["path"]), None)
    identity = ["-i", with_file["path"]] if with_file else []
    public = [
        {name: value for name, value in key.items() if name != "private_path"}
        for key in keys.values()
    ]
    return {
        "target": target,
        "keys": public,
        "copy_command": shlex.join(["ssh-copy-id", *identity, target]),
        "generate_command": None if keys else shlex.join(["ssh-keygen", "-t", "ed25519"]),
        "agent_command": shlex.join(["ssh-add", *locked]) if locked else None,
    }
