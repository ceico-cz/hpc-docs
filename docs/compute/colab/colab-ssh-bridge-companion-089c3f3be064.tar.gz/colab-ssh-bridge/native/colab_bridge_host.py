#!/usr/bin/env python3
from colab_bridge.host import main


if __name__ == "__main__":
    raise SystemExit(main())

