#!/usr/bin/env bash
set -euo pipefail

script_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
project_dir=$(cd -- "$script_dir/.." && pwd)
install_dir=${XDG_DATA_HOME:-"$HOME/.local/share"}/colab-ssh-bridge
manifest_dir="$HOME/.mozilla/native-messaging-hosts"
manifest="$manifest_dir/cz.ceico.colab_ssh_bridge.json"

command -v python3 >/dev/null 2>&1 || {
  printf 'error: python3 is required\n' >&2
  exit 127
}

mkdir -p "$install_dir" "$manifest_dir"
chmod 700 "$install_dir" "$manifest_dir"
cp -R "$project_dir/native/colab_bridge" "$install_dir/"
install -m 0755 "$project_dir/native/colab_bridge_host.py" "$install_dir/colab_bridge_host.py"
# The commit being installed, shown on the extension's options page. Release
# installers pass it in; a checkout reports its HEAD, marked if native/ differs.
build=${COLAB_BRIDGE_BUILD:-}
if [[ -z "$build" ]] && build=$(git -C "$project_dir" rev-parse --short=12 HEAD 2>/dev/null); then
  [[ -z "$(git -C "$project_dir" status --porcelain -- native)" ]] || build="$build-modified"
fi
printf '%s\n' "${build:-unknown}" >"$install_dir/BUILD"

python3 - "$manifest" "$install_dir/colab_bridge_host.py" <<'PY'
import json
import os
import sys
from pathlib import Path

manifest = Path(sys.argv[1])
host = str(Path(sys.argv[2]).resolve())
value = {
    "name": "cz.ceico.colab_ssh_bridge",
    "description": "Native SSH and Slurm companion for Colab SSH Bridge",
    "path": host,
    "type": "stdio",
    # The signed release, and the tester builds from before it.
    "allowed_extensions": ["colab-ssh-bridge@hpc.ceico.cz", "colab-ssh-bridge@local"],
}
temporary = manifest.with_suffix(".json.tmp")
temporary.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")
os.chmod(temporary, 0o600)
os.replace(temporary, manifest)
PY

printf 'Installed native host: %s\n' "$manifest"
if [[ -f "$project_dir/extension/manifest.json" ]]; then
  printf 'Load the extension temporarily from: %s/extension/manifest.json\n' "$project_dir"
fi

