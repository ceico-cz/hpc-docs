"""Fetch the upstream image or project onto the cluster, verified, with progress reporting."""

from __future__ import annotations

import asyncio
import re
import shlex
import shutil
import urllib.request
from dataclasses import dataclass
from typing import Any, Awaitable, Callable

from .models import uses_gpu, validate_profile
from .protocol import redact
from .ssh import remote_path_expr, ssh_target, stream_ssh

# Fixed here, never taken from the extension, so a message cannot point the cluster elsewhere.
UPSTREAM = "https://fzu.cz/~jose/apptainer/colab"
IMAGE_URL = f"{UPSTREAM}/colab-gpu.sif"
# Profiles that request no GPU get the much smaller CPU-only build.
CPU_IMAGE_URL = f"{UPSTREAM}/colab-cpu.sif"
# col-app releases are immutable col-app-<version>.tar.gz files; the manifest names the latest.
PROJECT_MANIFEST_URL = f"{UPSTREAM}/col-app.manifest"
PROJECT_ARCHIVE_PREFIX = f"{UPSTREAM}/col-app-"
VERSION_RE = re.compile(r"^[0-9a-f]{7,40}$")
# col-app is tooling the bridge owns, so it lives in the user's data directory on the cluster:
# one directory per release under versions/, and `current` pointing at the newest. The path
# is fixed rather than taken from XDG_DATA_HOME, which login shells and Slurm jobs may see
# differently, so the installer and every job agree on it.
RUNTIME_ROOT_DISPLAY = "~/.local/share/colab-ssh-bridge/col-app"
RUNTIME_ROOT_SH = 'runtime_root="$HOME"/.local/share/colab-ssh-bridge/col-app\n'
DOWNLOAD_ID_RE = re.compile(r"^[A-Za-z0-9_-]{1,64}$")
PHASES = {"preparing", "downloading", "verifying", "installing"}

EventSink = Callable[[dict[str, Any]], Awaitable[None]]

# Shared by both installers; runs under `bash -s` on the login node and every stdout
# line is "key|..." for the host. Each installer ends by calling `main`, so bash has
# parsed everything before any child process can touch stdin.
COMMON_SCRIPT = r"""
set -u
# Globals, not locals: the EXIT trap runs after main has returned.
tmp=""
tmpdir=""
pid=""
emit() { printf '%s\n' "$1" 2>/dev/null || exit 141; }
fail() { emit "error|$1"; exit 1; }
cleanup() {
  # No output here: stdout may be the closed pipe that brought us here.
  [ -n "$pid" ] && kill "$pid" 2>/dev/null && wait "$pid" 2>/dev/null
  [ -n "$tmp" ] && rm -f -- "$tmp"
  [ -n "$tmpdir" ] && rm -rf -- "$tmpdir"
}
trap cleanup EXIT
trap 'exit 129' HUP
trap 'exit 130' INT
trap 'exit 143' TERM
trap 'exit 141' PIPE

prepare_target() {
  [ -e "$dest" ] && fail "$dest already exists; it is never replaced"
  dir=$(dirname -- "$dest")
  name=$(basename -- "$dest")
  mkdir -p -- "$dir" 2>/dev/null || fail "cannot create $dir"
  [ -d "$dir" ] && [ -w "$dir" ] && [ -x "$dir" ] || fail "$dir is not a writable directory"
  # Leftovers of an interrupted run are removed; a fragment changed in the last
  # two minutes belongs to a run that is still going.
  local old
  for old in "$dir/.$name.part."*; do
    [ -e "$old" ] || continue
    if [ -n "$(find "$old" -maxdepth 0 -mmin -2 2>/dev/null)" ]; then
      fail "another download into $dest is in progress"
    fi
    rm -rf -- "$old" || fail "cannot remove stale fragment $old"
    emit "note|removed stale fragment $old"
  done
}

choose_tool() {
  if command -v curl >/dev/null 2>&1; then
    tool=curl
  elif command -v wget >/dev/null 2>&1; then
    tool=wget
  elif command -v python3 >/dev/null 2>&1; then
    tool=python3
  else
    fail "none of curl, wget or python3 is available on the login node"
  fi
  emit "tool|$tool"
}

read_checksum() {
  expected=$(fetch "$url.sha256" - </dev/null | head -c 4096 | awk 'NR == 1 { print tolower($1) }')
  case $expected in
    *[!0-9a-f]*|"") fail "could not read a SHA-256 checksum from $url.sha256" ;;
  esac
  [ ${#expected} -eq 64 ] || fail "could not read a SHA-256 checksum from $url.sha256"
}

check_space() {
  # check_space LIMIT: the size announced by the server must fit LIMIT (0: none) and the disk.
  local avail
  total=$(content_length "$url" </dev/null)
  case $total in ''|*[!0-9]*) total=0 ;; esac
  [ "$total" -eq 0 ] && return
  if [ "$1" -gt 0 ] && [ "$total" -gt "$1" ]; then
    fail "upstream file is $total bytes, more than the expected at most $1"
  fi
  avail=$(df -Pk -- "$dir" 2>/dev/null | awk 'NR == 2 { print $4 }')
  case $avail in ''|*[!0-9]*) return ;; esac
  # Keep 64 MiB of headroom beyond the file itself.
  [ $((avail * 1024)) -gt $((total + 67108864)) ] ||
    fail "not enough free space in $dir: $((total / 1048576)) MiB needed, $((avail / 1024)) MiB free"
}

transfer() {
  local status
  tmp=$(mktemp -- "$dir/.$name.part.XXXXXX") || fail "cannot create a temporary file in $dir"
  emit "phase|downloading"
  fetch "$url" "$tmp" </dev/null &
  pid=$!
  while kill -0 "$pid" 2>/dev/null; do
    size=$(stat -c %s -- "$tmp" 2>/dev/null || echo 0)
    emit "progress|$size|$total"
    sleep 1
  done
  wait "$pid"
  status=$?
  pid=""
  [ "$status" -eq 0 ] || fail "download failed ($tool exit $status)"
}

verify_download() {
  emit "phase|verifying"
  size=$(stat -c %s -- "$tmp" 2>/dev/null || echo 0)
  emit "progress|$size|$total"
  if [ "$total" -gt 0 ] && [ "$size" -ne "$total" ]; then
    fail "download is incomplete: $size of $total bytes"
  fi
  if command -v sha256sum >/dev/null 2>&1; then
    actual=$(sha256sum -- "$tmp" | awk '{ print $1 }')
  else
    actual=$(python3 -c 'import hashlib, sys
h = hashlib.sha256()
with open(sys.argv[1], "rb") as f:
    for block in iter(lambda: f.read(1 << 20), b""):
        h.update(block)
print(h.hexdigest())' "$tmp")
  fi
  [ "$actual" = "$expected" ] || fail "checksum mismatch: expected $expected, got $actual"
}

fetch() {
  # fetch URL OUTPUT: download over HTTPS only, following HTTPS redirects; OUTPUT "-" is stdout.
  # Always called in a subshell; exec makes the tool itself the process the trap kills.
  case $tool in
    curl)
      exec curl -fsSL --proto '=https' --proto-redir '=https' --tlsv1.2 --connect-timeout 30 \
        --speed-limit 1024 --speed-time 120 -o "$2" -- "$1" ;;
    wget)
      exec wget -q --https-only --secure-protocol=TLSv1_2 --timeout=120 --tries=1 -O "$2" -- "$1" ;;
    python3)
      exec python3 -c '
import shutil, sys, urllib.request
url, out = sys.argv[1:3]
if not url.startswith("https://"):
    sys.exit("only HTTPS URLs are allowed")
with urllib.request.urlopen(url, timeout=120) as response:
    if not response.geturl().startswith("https://"):
        sys.exit("redirected away from HTTPS")
    if out == "-":
        shutil.copyfileobj(response, sys.stdout.buffer, 1 << 20)
    else:
        with open(out, "wb") as stream:
            shutil.copyfileobj(response, stream, 1 << 20)
' "$1" "$2" ;;
  esac
}

content_length() {
  # Size of the final response after redirects, or nothing when the server does not say.
  case $tool in
    curl)
      curl -fsSIL --proto '=https' --proto-redir '=https' --tlsv1.2 --connect-timeout 30 \
        --max-time 60 -- "$1" 2>/dev/null ;;
    wget)
      wget -q -S --spider --https-only --secure-protocol=TLSv1_2 --timeout=60 --tries=1 -- "$1" 2>&1 ;;
    python3)
      python3 -c '
import sys, urllib.request
request = urllib.request.Request(sys.argv[1], method="HEAD")
with urllib.request.urlopen(request, timeout=60) as response:
    print("Content-Length:", response.headers.get("Content-Length", ""))
' "$1" 2>/dev/null ;;
  esac | tr -d '\r' | awk 'tolower($1) == "content-length:" { size = $2 } END { print size }'
}
"""

IMAGE_SCRIPT = r"""
main() {
  local dir name tool total expected actual size magic mode
  emit "phase|preparing"
  case $dest in *.sif) ;; *) fail "the SIF path must end in .sif" ;; esac
  prepare_target
  choose_tool
  read_checksum
  check_space 0
  transfer
  verify_download
  magic=$(dd if="$tmp" bs=1 skip=32 count=9 2>/dev/null)
  [ "$magic" = SIF_MAGIC ] || fail "downloaded file is not a SIF image"

  emit "phase|installing"
  # mktemp creates 0600 files; give the image the permissions a new file would get.
  mode=$(printf '%o' $((0666 & ~$(umask))))
  chmod "$mode" -- "$tmp" || fail "cannot set permissions on the downloaded image"
  # -n refuses to replace an image that appeared meanwhile; the fragment is then removed.
  mv -n -- "$tmp" "$dest" 2>/dev/null
  if [ -e "$tmp" ]; then
    [ -e "$dest" ] && fail "$dest appeared during the download; kept the existing file"
    fail "cannot move the image into place"
  fi
  tmp=""
  emit "done|$size|$actual"
}
main
exit
"""

# The project is a `git archive` of col-app: files at the top level, run.sh among them.
PROJECT_SCRIPT = r"""
read_manifest() {
  # Sets version, expected (SHA-256) and expected_size from the upstream manifest.
  local manifest
  manifest=$(fetch "$manifest_url" - </dev/null | head -c 4096 | tr -d '\r')
  version=$(printf '%s\n' "$manifest" | sed -n 's/^version=//p' | head -n 1)
  expected=$(printf '%s\n' "$manifest" | sed -n 's/^sha256=//p' | head -n 1 | tr 'A-F' 'a-f')
  expected_size=$(printf '%s\n' "$manifest" | sed -n 's/^size=//p' | head -n 1)
  printf '%s\n' "$version" | grep -Eqx '[0-9a-f]{7,40}' ||
    fail "could not read a col-app version from $manifest_url"
  printf '%s\n' "$expected" | grep -Eqx '[0-9a-f]{64}' ||
    fail "could not read a SHA-256 checksum from $manifest_url"
  printf '%s\n' "$expected_size" | grep -Eqx '[0-9]{1,12}' ||
    fail "could not read the archive size from $manifest_url"
}

install_archive() {
  local listing mode
  prepare_target
  check_space "$limit"
  if [ "$total" -gt 0 ] && [ "$total" -ne "$expected_size" ]; then
    fail "upstream archive is $total bytes, the manifest says $expected_size"
  fi
  total=$expected_size
  [ "$total" -le "$limit" ] || fail "archive is larger than $limit bytes"
  transfer
  verify_download
  listing=$(tar -tzf "$tmp" 2>/dev/null) || fail "downloaded file is not a readable tar.gz archive"
  if printf '%s\n' "$listing" | grep -Eq '(^/|(^|/)\.\.(/|$))'; then
    fail "archive contains absolute or parent-directory paths"
  fi
  if tar -tzvf "$tmp" 2>/dev/null | cut -c1 | grep -q '[^-d]'; then
    fail "archive contains links or special files"
  fi
  printf '%s\n' "$listing" | grep -Eqx '(\./)?run\.sh' || fail "archive has no run.sh at its top level"

  emit "phase|installing"
  tmpdir=$(mktemp -d -- "$dir/.$name.part.XXXXXX") || fail "cannot create a temporary directory in $dir"
  tar -xzf "$tmp" -C "$tmpdir" --no-same-owner 2>/dev/null || fail "cannot unpack the archive"
  [ -x "$tmpdir/run.sh" ] || fail "run.sh in the archive is not executable"
  # mktemp -d creates 0700; give the project the permissions a new directory would get.
  mode=$(printf '%o' $((0777 & ~$(umask))))
  chmod "$mode" -- "$tmpdir" || fail "cannot set permissions on the project directory"
  rm -f -- "$tmp"
  tmp=""
  # -T renames the directory itself; -n refuses to replace anything that appeared meanwhile.
  mv -nT -- "$tmpdir" "$dest" 2>/dev/null
  if [ -e "$tmpdir" ]; then
    [ -e "$dest" ] && fail "$dest appeared during the download; kept the existing directory"
    fail "cannot move the project into place"
  fi
  tmpdir=""
}

main() {
  local dir name tool total expected expected_size version actual size link
  local limit=67108864
  emit "phase|preparing"
  choose_tool
  read_manifest
  # Only the version comes from the manifest, and it is plain hex: the URL and path stay ours.
  url="$base_url$version.tar.gz"
  dest="$runtime_root/versions/$version"
  if [ -e "$dest" ]; then
    # A release is never changed once published, so an unpacked copy is reused as is.
    [ -x "$dest/run.sh" ] || fail "$dest exists without an executable run.sh; remove it to reinstall"
    emit "note|col-app $version was already unpacked"
    size=0
    actual=$expected
  else
    install_archive
  fi
  # Swap the link atomically; running jobs resolved their release when they started. The
  # link is staged in a private directory: PIDs can repeat across login nodes sharing $HOME.
  tmpdir=$(mktemp -d -- "$runtime_root/.current.XXXXXX") ||
    fail "cannot create a temporary directory in $runtime_root"
  link="$tmpdir/current"
  if ! { ln -s -- "versions/$version" "$link" && mv -Tf -- "$link" "$runtime_root/current"; }; then
    fail "cannot point $runtime_root/current at $version"
  fi
  rmdir -- "$tmpdir"
  tmpdir=""
  emit "installed|$version|$dest"
  emit "done|$size|$actual"
}
main
exit
"""


@dataclass(frozen=True)
class DownloadKind:
    url: str
    # Profile field naming the target; None when the bridge owns the location.
    field: str | None
    script: str


KINDS = {
    "image": DownloadKind(IMAGE_URL, "image_path", IMAGE_SCRIPT),
    "project": DownloadKind(PROJECT_MANIFEST_URL, None, PROJECT_SCRIPT),
}


def download_url(kind: str, profile: dict[str, Any]) -> str:
    """Upstream URL for a download; the image variant is the one the job will run."""
    if kind == "image" and not uses_gpu(profile):
        return CPU_IMAGE_URL
    return KINDS[kind].url


def download_script(kind: str, profile: dict[str, Any]) -> str:
    spec = KINDS[kind]
    if spec.field:
        url = download_url(kind, profile)
        variables = f"dest={remote_path_expr(profile[spec.field])}\nurl={shlex.quote(url)}\n"
    else:
        variables = (
            RUNTIME_ROOT_SH
            + f"manifest_url={shlex.quote(spec.url)}\nbase_url={shlex.quote(PROJECT_ARCHIVE_PREFIX)}\n"
        )
    return variables + COMMON_SCRIPT + spec.script


def parse_manifest(text: str) -> dict[str, Any]:
    """Read the key=value col-app manifest; anything malformed is refused."""
    values: dict[str, str] = {}
    for line in text.splitlines():
        key, sep, value = line.strip().partition("=")
        if sep and key not in values:
            values[key] = value.strip()
    version = values.get("version", "")
    digest = values.get("sha256", "").lower()
    size = values.get("size", "")
    if not VERSION_RE.fullmatch(version):
        raise ValueError("manifest has no valid version")
    if not re.fullmatch(r"[0-9a-f]{64}", digest):
        raise ValueError("manifest has no valid sha256")
    if not re.fullmatch(r"[0-9]{1,12}", size):
        raise ValueError("manifest has no valid size")
    # Optional: the release's commit time; manifests published before it lack the key.
    committed = values.get("committed", "")
    return {
        "version": version,
        "sha256": digest,
        "size": int(size),
        "committed": int(committed) if re.fullmatch(r"[0-9]{1,12}", committed) else None,
    }


async def latest_project_release(timeout: float = 10) -> dict[str, Any]:
    """Fetch the upstream col-app manifest from this machine."""

    def fetch() -> str:
        with urllib.request.urlopen(PROJECT_MANIFEST_URL, timeout=timeout) as response:
            if not response.geturl().startswith("https://"):
                raise ValueError("manifest was redirected away from HTTPS")
            return response.read(4096).decode("utf-8", "replace")

    return parse_manifest(await asyncio.to_thread(fetch))


def parse_download_line(line: str) -> dict[str, Any] | None:
    """Turn one script output line into an event payload, ignoring anything unexpected."""
    key, _, rest = line.partition("|")
    if key == "phase" and rest in PHASES:
        return {"phase": rest}
    if key == "progress":
        done, _, total = rest.partition("|")
        if done.isdigit() and total.isdigit():
            return {"phase": "downloading", "bytes": int(done), "total": int(total) or None}
    if key == "tool" and rest in {"curl", "wget", "python3"}:
        return {"tool": rest}
    if key == "note":
        return {"note": redact(rest)}
    if key == "error":
        return {"error": redact(rest)}
    if key == "installed":
        version, _, path = rest.partition("|")
        if VERSION_RE.fullmatch(version) and path:
            return {"version": version, "path": redact(path)}
    if key == "done":
        size, _, digest = rest.partition("|")
        if size.isdigit() and re.fullmatch(r"[0-9a-f]{64}", digest):
            return {"phase": "done", "bytes": int(size), "sha256": digest}
    return None


class RemoteDownloads:
    """Tracks downloads onto the cluster so each can report progress and be cancelled."""

    def __init__(self, emit: EventSink) -> None:
        self.emit = emit
        self.tasks: dict[str, asyncio.Task[dict[str, Any]]] = {}
        self.destinations: dict[str, str] = {}

    async def download(self, kind: Any, raw: Any, download_id: str) -> dict[str, Any]:
        if kind not in KINDS:
            raise ValueError("unknown download kind")
        if not DOWNLOAD_ID_RE.fullmatch(download_id):
            raise ValueError("invalid download_id")
        if download_id in self.tasks:
            raise ValueError("download_id is already in use")
        if not isinstance(raw, dict):
            raise ValueError("profile must be an object")
        field = KINDS[kind].field
        # Only the connection, the target path and the GRES (for the image variant) matter;
        # the rest of the draft may be unfinished.
        keys = ("ssh_target", "ssh_user", "gres_type", "gres_count", *((field,) if field else ()))
        lookup = {key: raw[key] for key in keys if key in raw}
        profile = validate_profile({"id": "download", "name": "Download", "backend": "slurm", **lookup})
        target = profile[field] if field else "col-app"
        destination = f"{ssh_target(profile)}:{target}"
        if destination in self.destinations.values():
            raise ValueError(f"{target} is already being downloaded")
        if not shutil.which("ssh"):
            raise RuntimeError("ssh executable not found")
        self.destinations[download_id] = destination
        task = asyncio.create_task(self._run(kind, profile, download_id))
        self.tasks[download_id] = task

        def forget(_task: asyncio.Task[dict[str, Any]]) -> None:
            self.tasks.pop(download_id, None)
            self.destinations.pop(download_id, None)

        task.add_done_callback(forget)
        return await task

    def cancel(self, download_id: str) -> bool:
        task = self.tasks.get(download_id)
        if not task or task.done():
            return False
        task.cancel()
        return True

    async def close(self) -> None:
        for task in list(self.tasks.values()):
            task.cancel()
        await asyncio.gather(*self.tasks.values(), return_exceptions=True)

    async def _run(self, kind: str, profile: dict[str, Any], download_id: str) -> dict[str, Any]:
        state: dict[str, Any] = {"phase": "preparing", "bytes": 0, "total": None}
        errors: list[str] = []

        async def on_line(line: str) -> None:
            update = parse_download_line(line)
            if not update:
                return
            if "error" in update:
                errors.append(update["error"])
                return
            state.update(update)
            await self.emit(
                {
                    "version": 1,
                    "type": "event",
                    "event": "download",
                    "download_id": download_id,
                    **state,
                }
            )
            state.pop("note", None)

        try:
            result = await stream_ssh(
                profile, "bash -s", on_line, input_text=download_script(kind, profile)
            )
        except asyncio.CancelledError:
            raise RuntimeError("download cancelled; no partial file was kept") from None
        if state["phase"] != "done" or result.returncode:
            stderr = result.stderr.strip().splitlines()
            detail = errors[-1] if errors else redact(stderr[-1]) if stderr else ""
            raise RuntimeError(detail or f"download failed (exit {result.returncode})")
        field = KINDS[kind].field
        result = {
            "kind": kind,
            "path": state.get("path") or (profile[field] if field else RUNTIME_ROOT_DISPLAY),
            "bytes": state["bytes"],
            "sha256": state["sha256"],
            "url": download_url(kind, profile),
        }
        if "version" in state:
            result["version"] = state["version"]
        return result
